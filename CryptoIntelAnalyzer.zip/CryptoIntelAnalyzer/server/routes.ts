import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import fs from "fs";
import { db } from "@db";
import { reports } from "@shared/schema";
import { eq } from "drizzle-orm";
import * as cryptoService from "./services/crypto-service";
import * as openaiService from "./services/openai-service";
import * as pdfService from "./services/pdf-service";
import * as paymentService from "./services/payment-service";

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Crypto API Routes
  app.get("/api/crypto/prices", async (req, res) => {
    try {
      const { coins } = req.query;
      if (!coins) {
        return res.status(400).json({ error: "Missing coins parameter" });
      }
      
      const coinIds = (coins as string).split(',');
      const prices = await cryptoService.getCoinPrices(coinIds);
      
      res.json(prices);
    } catch (error) {
      console.error("Error fetching crypto prices:", error);
      res.status(500).json({ error: "Failed to fetch crypto prices" });
    }
  });

  app.get("/api/crypto/history", async (req, res) => {
    try {
      const { coin, days, interval } = req.query;
      if (!coin) {
        return res.status(400).json({ error: "Missing coin parameter" });
      }
      
      const history = await cryptoService.getCoinHistoricalData(
        coin as string,
        days ? Number(days) : 30,
        interval as string || 'daily'
      );
      
      res.json(history);
    } catch (error) {
      console.error("Error fetching crypto history:", error);
      res.status(500).json({ error: "Failed to fetch crypto history" });
    }
  });

  app.get("/api/crypto/search", async (req, res) => {
    try {
      const { query } = req.query;
      if (!query) {
        return res.status(400).json({ error: "Missing query parameter" });
      }
      
      const results = await cryptoService.searchCoins(query as string);
      
      res.json(results);
    } catch (error) {
      console.error("Error searching crypto:", error);
      res.status(500).json({ error: "Failed to search cryptocurrencies" });
    }
  });

  app.get("/api/crypto/global", async (req, res) => {
    try {
      const globalData = await cryptoService.getGlobalMarketData();
      
      res.json(globalData);
    } catch (error) {
      console.error("Error fetching global market data:", error);
      res.status(500).json({ error: "Failed to fetch global market data" });
    }
  });

  // Portfolio Analysis Routes
  app.post("/api/analysis", upload.array("files", 5), async (req, res) => {
    try {
      // Parse the form data
      const formData = JSON.parse(req.body.data);
      const uploadedFiles = req.files as Express.Multer.File[];
      
      // Extract client information and holdings
      const clientInfo = formData.client;
      const holdings = formData.holdings;
      const profile = formData.profile;
      
      // Process uploaded files if any
      let extractedText = "";
      if (uploadedFiles && uploadedFiles.length > 0) {
        for (const file of uploadedFiles) {
          if (file.mimetype.startsWith('image/')) {
            // Extract text from image using OpenAI Vision API
            const base64Image = file.buffer.toString('base64');
            const textFromImage = await openaiService.extractTextFromImage(base64Image);
            extractedText += textFromImage + "\n\n";
          } else if (file.mimetype === 'text/plain' || file.mimetype === 'text/csv') {
            // Extract text from text files
            extractedText += file.buffer.toString('utf-8') + "\n\n";
          }
        }
      }
      
      // Get market data for the holdings
      const coinIds = holdings.map((h: any) => h.name.toLowerCase());
      const marketData = {
        prices: await cryptoService.getCoinPrices(coinIds),
        global: await cryptoService.getGlobalMarketData()
      };
      
      // For the main coin (first in the list), get historical data
      let priceHistory = { dates: [], prices: [] };
      if (coinIds.length > 0) {
        priceHistory = await cryptoService.getCoinHistoricalData(coinIds[0], 30);
      }
      
      marketData.priceHistory = priceHistory;
      
      // Calculate portfolio metrics
      const portfolioMetrics = await cryptoService.calculatePortfolioMetrics(holdings);
      
      // Analyze portfolio with OpenAI
      const analysisResult = await openaiService.analyzeCryptoPortfolio(
        clientInfo,
        holdings,
        profile,
        {
          prices: marketData.prices,
          global: marketData.global,
          portfolioMetrics,
          extractedText
        }
      );
      
      // Store report in database
      const [newReport] = await db.insert(reports).values({
        reportId: analysisResult.report.id,
        clientName: clientInfo.name,
        clientEmail: clientInfo.email,
        reportData: JSON.stringify(analysisResult.report),
        generatedAt: new Date().toISOString()
      }).returning();
      
      res.status(201).json({ reportId: analysisResult.report.id });
    } catch (error) {
      console.error("Error analyzing portfolio:", error);
      res.status(500).json({ error: "Failed to analyze portfolio" });
    }
  });

  app.get("/api/reports/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Special case for sample report
      if (id === 'sample') {
        const sampleReport = await storage.getSampleReport();
        return res.json(sampleReport);
      }
      
      // Get report from database
      const report = await db.query.reports.findFirst({
        where: eq(reports.reportId, id)
      });
      
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      
      // Parse the report data
      const reportData = JSON.parse(report.reportData);
      
      res.json(reportData);
    } catch (error) {
      console.error("Error fetching report:", error);
      res.status(500).json({ error: "Failed to fetch report" });
    }
  });

  app.get("/api/reports/:id/pdf", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Special case for sample report
      if (id === 'sample') {
        const sampleReport = await storage.getSampleReport();
        const pdfBuffer = await pdfService.generatePDF({ report: sampleReport });
        
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename=sample-crypto-analysis.pdf');
        return res.send(pdfBuffer);
      }
      
      // Get report from database
      const report = await db.query.reports.findFirst({
        where: eq(reports.reportId, id)
      });
      
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      
      // Parse the report data
      const reportData = JSON.parse(report.reportData);
      
      // Generate PDF
      const pdfBuffer = await pdfService.generatePDF({ report: reportData });
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename=crypto-analysis-${id}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Error generating PDF:", error);
      res.status(500).json({ error: "Failed to generate PDF" });
    }
  });

  // Payment Routes
  app.post("/api/payment/verify", async (req, res) => {
    try {
      const { reportId, txid, sessionId } = req.body;
      
      if (!reportId || !txid) {
        return res.status(400).json({ 
          success: false, 
          message: "Missing required parameters" 
        });
      }
      
      // Use the session ID or generate one if not provided
      const effectiveSessionId = sessionId || req.sessionID || `session_${Date.now()}`;
      
      // Verify the payment using the payment service
      const result = await paymentService.verifyPayment(reportId, txid, effectiveSessionId);
      
      res.json(result);
    } catch (error) {
      console.error("Error verifying payment:", error);
      res.status(500).json({ 
        success: false, 
        message: "Failed to verify payment" 
      });
    }
  });
  
  app.get("/api/payment/status/:reportId", async (req, res) => {
    try {
      const { reportId } = req.params;
      
      if (!reportId) {
        return res.status(400).json({ error: "Missing report ID" });
      }
      
      const status = await paymentService.getPaymentStatus(reportId);
      
      res.json({ status });
    } catch (error) {
      console.error("Error getting payment status:", error);
      res.status(500).json({ error: "Failed to get payment status" });
    }
  });

  app.get("/api/payment/transaction/:txid", async (req, res) => {
    try {
      const { txid } = req.params;
      
      if (!txid) {
        return res.status(400).json({ error: "Missing transaction ID" });
      }
      
      const details = await paymentService.getTransactionDetails(txid);
      
      if (!details) {
        return res.status(404).json({ error: "Transaction not found on the blockchain" });
      }
      
      res.json(details);
    } catch (error) {
      console.error("Error fetching transaction details:", error);
      res.status(500).json({ error: "Failed to fetch transaction details" });
    }
  });

  // Get payment details with tiny-precision unique amount for anti-front-running
  app.get("/api/payment/details/:reportId", async (req, res) => {
    try {
      const { reportId } = req.params;
      
      // Use the session ID or generate a unique one
      const sessionId = req.sessionID || `session_${Date.now()}`;
      
      // Generate a unique amount for this payment session (with 4 decimal precision)
      const uniqueAmount = paymentService.generateUniquePaymentAmount(reportId, sessionId);
      
      res.json({ 
        address: 'TBNwZnv9rU28cpJhJyw9D55kiPqE7qWdFd',
        amount: uniqueAmount,
        currency: 'USDT',
        network: 'TRC20',
        sessionId: sessionId,
        instructions: `Please send EXACTLY ${uniqueAmount.toFixed(4)} USDT to verify ownership. The 4th decimal place acts as your unique identifier.`
      });
    } catch (error) {
      console.error("Error getting payment details:", error);
      res.status(500).json({ error: "Failed to get payment details" });
    }
  });
  
  // Legacy endpoint for compatibility
  app.get("/api/payment/address", async (req, res) => {
    try {
      res.json({ 
        address: 'TBNwZnv9rU28cpJhJyw9D55kiPqE7qWdFd',
        amount: 10,
        currency: 'USDT',
        network: 'TRC20'
      });
    } catch (error) {
      console.error("Error getting payment address:", error);
      res.status(500).json({ error: "Failed to get payment address" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
