import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface AnalysisResult {
  report: {
    id: string;
    generatedAt: string;
    portfolio: {
      totalValue: number;
      distribution: Array<{
        coin: string;
        symbol: string;
        percentage: number;
      }>;
      overallPerformance: number;
      coinPerformance: Array<{
        name: string;
        symbol: string;
        performance: number;
      }>;
      riskScore: number;
      riskLevel: string;
      diversificationScore: number;
      diversificationStatus: string;
    };
    marketInsights: Array<{
      title: string;
      sentiment: 'bullish' | 'bearish';
      description: string;
    }>;
    recommendations: Array<{
      type: 'portfolio' | 'strategy' | 'risk';
      title: string;
      description: string;
    }>;
    opportunities: Array<{
      name: string;
      symbol: string;
      status: string;
    }>;
  }
}

export async function analyzeCryptoPortfolio(
  clientInfo: any,
  holdings: any[],
  profile: any,
  marketData: any
): Promise<AnalysisResult> {
  try {
    const prompt = `
      Analyze this crypto portfolio and provide detailed insights and recommendations.
      
      Client Information:
      - Name: ${clientInfo.name}
      - Email: ${clientInfo.email}
      
      Investment Profile:
      - Timeframe: ${profile.timeframe}
      - Risk Appetite: ${profile.risk}
      - Investment Goal: ${profile.goal}
      - Additional Notes: ${profile.notes || 'None provided'}
      
      Crypto Holdings:
      ${holdings.map(h => `- ${h.name}: ${h.quantity} coins at average buy price of $${h.buyPrice}`).join('\n')}
      
      Current Market Data:
      ${JSON.stringify(marketData, null, 2)}
      
      Please provide a comprehensive analysis including:
      1. Portfolio overview (total value, distribution, performance)
      2. Risk assessment and diversification score
      3. Market insights for each major coin
      4. Specific recommendations based on client's investment profile
      5. Potential investment opportunities
      
      Return the response as a detailed JSON object with the following structure:
      {
        "portfolio": {
          "totalValue": number,
          "distribution": [{"coin": string, "symbol": string, "percentage": number}],
          "overallPerformance": number,
          "coinPerformance": [{"name": string, "symbol": string, "performance": number}],
          "riskScore": number,
          "riskLevel": string,
          "diversificationScore": number,
          "diversificationStatus": string
        },
        "marketInsights": [{"title": string, "sentiment": "bullish" | "bearish", "description": string}],
        "recommendations": [{"type": "portfolio" | "strategy" | "risk", "title": string, "description": string}],
        "opportunities": [{"name": string, "symbol": string, "status": string}]
      }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are a professional cryptocurrency analyst and financial advisor. Provide detailed, data-driven analysis and actionable recommendations." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });

    const analysisResult = JSON.parse(response.choices[0].message.content);
    
    // Add metadata to the analysis
    const reportId = generateReportId();
    const generatedAt = new Date().toLocaleDateString('en-US', {
      year: 'numeric', 
      month: 'long', 
      day: 'numeric'
    });

    return {
      report: {
        id: reportId,
        generatedAt,
        ...analysisResult
      }
    };
  } catch (error) {
    console.error('Error analyzing portfolio with OpenAI:', error);
    throw new Error('Failed to analyze portfolio. Please try again later.');
  }
}

export async function extractTextFromImage(base64Image: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Extract all cryptocurrency holdings information from this image. Identify coin names, quantities, and purchase prices if present. Format as a structured list."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      max_tokens: 500,
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error('Error extracting text from image:', error);
    throw new Error('Failed to extract text from image. Please try again.');
  }
}

function generateReportId(): string {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}
