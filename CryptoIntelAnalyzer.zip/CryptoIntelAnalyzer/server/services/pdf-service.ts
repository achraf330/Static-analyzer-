import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import fs from 'fs';
import path from 'path';
import { AnalysisResult } from './openai-service';
import { formatCurrency, formatPercentage } from './utils';

export async function generatePDF(analysis: AnalysisResult): Promise<Buffer> {
  try {
    const pdfDoc = await PDFDocument.create();
    const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    // Add the first page - Cover
    const coverPage = pdfDoc.addPage([612, 792]);
    const { width, height } = coverPage.getSize();
    
    // Cover page
    coverPage.drawText('Crypto Portfolio Analysis', {
      x: 50,
      y: height - 100,
      size: 30,
      font: helveticaBold,
      color: rgb(0.2, 0.2, 0.8),
    });
    
    coverPage.drawText(`Generated on ${analysis.report.generatedAt}`, {
      x: 50,
      y: height - 140,
      size: 14,
      font: helveticaFont,
      color: rgb(0.3, 0.3, 0.3),
    });
    
    // Add portfolio summary page
    const summaryPage = pdfDoc.addPage([612, 792]);
    
    // Header
    summaryPage.drawText('Portfolio Summary', {
      x: 50,
      y: height - 50,
      size: 24,
      font: helveticaBold,
      color: rgb(0.2, 0.2, 0.8),
    });
    
    // Total value
    summaryPage.drawText(`Total Value: ${formatCurrency(analysis.report.portfolio.totalValue)}`, {
      x: 50,
      y: height - 100,
      size: 14,
      font: helveticaBold,
    });
    
    // Overall performance
    const performanceColor = analysis.report.portfolio.overallPerformance >= 0 
      ? rgb(0.2, 0.6, 0.2) // green
      : rgb(0.8, 0.2, 0.2); // red
      
    summaryPage.drawText(`Overall Performance: ${formatPercentage(analysis.report.portfolio.overallPerformance)}`, {
      x: 50,
      y: height - 130,
      size: 14,
      font: helveticaBold,
      color: performanceColor,
    });
    
    // Risk & Diversification
    summaryPage.drawText(`Risk Score: ${analysis.report.portfolio.riskScore}/10 (${analysis.report.portfolio.riskLevel})`, {
      x: 50,
      y: height - 160,
      size: 12,
      font: helveticaFont,
    });
    
    summaryPage.drawText(`Diversification: ${analysis.report.portfolio.diversificationScore}/10 (${analysis.report.portfolio.diversificationStatus})`, {
      x: 50,
      y: height - 180,
      size: 12,
      font: helveticaFont,
    });
    
    // Holdings Section
    summaryPage.drawText('Holdings Breakdown', {
      x: 50,
      y: height - 220,
      size: 18,
      font: helveticaBold,
    });
    
    let yPosition = height - 250;
    analysis.report.portfolio.distribution.forEach((coin, index) => {
      summaryPage.drawText(`${coin.coin} (${coin.symbol}): ${coin.percentage.toFixed(1)}%`, {
        x: 50,
        y: yPosition,
        size: 12,
        font: helveticaFont,
      });
      yPosition -= 20;
    });
    
    // Add recommendations page
    const recPage = pdfDoc.addPage([612, 792]);
    
    // Header
    recPage.drawText('Recommendations', {
      x: 50,
      y: height - 50,
      size: 24,
      font: helveticaBold,
      color: rgb(0.2, 0.2, 0.8),
    });
    
    // Recommendations
    yPosition = height - 100;
    analysis.report.recommendations.forEach((rec, index) => {
      recPage.drawText(`${index + 1}. ${rec.title}`, {
        x: 50,
        y: yPosition,
        size: 14,
        font: helveticaBold,
      });
      yPosition -= 25;
      
      // Handle text wrapping for description
      const words = rec.description.split(' ');
      let line = '';
      const maxWidth = width - 100;
      for (const word of words) {
        const testLine = line + word + ' ';
        const textWidth = helveticaFont.widthOfTextAtSize(testLine, 12);
        
        if (textWidth > maxWidth) {
          recPage.drawText(line, {
            x: 50,
            y: yPosition,
            size: 12,
            font: helveticaFont,
          });
          line = word + ' ';
          yPosition -= 20;
        } else {
          line = testLine;
        }
      }
      
      if (line) {
        recPage.drawText(line, {
          x: 50,
          y: yPosition,
          size: 12,
          font: helveticaFont,
        });
      }
      
      yPosition -= 30;
    });
    
    // Add market insights page
    const insightsPage = pdfDoc.addPage([612, 792]);
    
    // Header
    insightsPage.drawText('Market Insights', {
      x: 50,
      y: height - 50,
      size: 24,
      font: helveticaBold,
      color: rgb(0.2, 0.2, 0.8),
    });
    
    // Market insights
    yPosition = height - 100;
    analysis.report.marketInsights.forEach((insight, index) => {
      const sentimentColor = insight.sentiment === 'bullish' 
        ? rgb(0.2, 0.6, 0.2) // green
        : rgb(0.8, 0.2, 0.2); // red
        
      insightsPage.drawText(`${insight.title} (${insight.sentiment.toUpperCase()})`, {
        x: 50,
        y: yPosition,
        size: 14,
        font: helveticaBold,
        color: sentimentColor,
      });
      yPosition -= 25;
      
      // Handle text wrapping for description
      const words = insight.description.split(' ');
      let line = '';
      const maxWidth = width - 100;
      for (const word of words) {
        const testLine = line + word + ' ';
        const textWidth = helveticaFont.widthOfTextAtSize(testLine, 12);
        
        if (textWidth > maxWidth) {
          insightsPage.drawText(line, {
            x: 50,
            y: yPosition,
            size: 12,
            font: helveticaFont,
          });
          line = word + ' ';
          yPosition -= 20;
        } else {
          line = testLine;
        }
      }
      
      if (line) {
        insightsPage.drawText(line, {
          x: 50,
          y: yPosition,
          size: 12,
          font: helveticaFont,
        });
      }
      
      yPosition -= 30;
    });
    
    // Investment opportunities
    if (analysis.report.opportunities.length > 0) {
      yPosition = Math.min(yPosition, height - 350);
      
      insightsPage.drawText('Investment Opportunities', {
        x: 50,
        y: yPosition,
        size: 18,
        font: helveticaBold,
      });
      
      yPosition -= 30;
      
      analysis.report.opportunities.forEach((opp) => {
        insightsPage.drawText(`${opp.name} (${opp.symbol}) - ${opp.status}`, {
          x: 50,
          y: yPosition,
          size: 12,
          font: helveticaFont,
        });
        yPosition -= 20;
      });
    }
    
    // Final page - Disclaimer
    const disclaimerPage = pdfDoc.addPage([612, 792]);
    
    disclaimerPage.drawText('Disclaimer', {
      x: 50,
      y: height - 50,
      size: 24,
      font: helveticaBold,
      color: rgb(0.2, 0.2, 0.8),
    });
    
    const disclaimer = `This report is for informational purposes only and does not constitute financial advice. Cryptocurrency investments are highly volatile and risky. Past performance is not indicative of future results. Always do your own research and consider consulting with a financial advisor before making investment decisions.`;
    
    // Handle text wrapping for disclaimer
    yPosition = height - 100;
    const words = disclaimer.split(' ');
    let line = '';
    const maxWidth = width - 100;
    for (const word of words) {
      const testLine = line + word + ' ';
      const textWidth = helveticaFont.widthOfTextAtSize(testLine, 12);
      
      if (textWidth > maxWidth) {
        disclaimerPage.drawText(line, {
          x: 50,
          y: yPosition,
          size: 12,
          font: helveticaFont,
        });
        line = word + ' ';
        yPosition -= 20;
      } else {
        line = testLine;
      }
    }
    
    if (line) {
      disclaimerPage.drawText(line, {
        x: 50,
        y: yPosition,
        size: 12,
        font: helveticaFont,
      });
    }
    
    // Get PDF as buffer
    const pdfBytes = await pdfDoc.save();
    return Buffer.from(pdfBytes);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw new Error('Failed to generate PDF report.');
  }
}

// Helper functions for formatting
function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(value);
}

function formatPercentage(value: number): string {
  const sign = value >= 0 ? '+' : '';
  return `${sign}${value.toFixed(1)}%`;
}
