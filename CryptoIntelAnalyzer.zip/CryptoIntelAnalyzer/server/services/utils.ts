/**
 * Utility functions for the crypto portfolio analysis application
 */

// Format currency values
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(value);
}

// Format percentage values
export function formatPercentage(value: number): string {
  const sign = value >= 0 ? '+' : '';
  return `${sign}${value.toFixed(1)}%`;
}

// Calculate the diversification index of a portfolio (Herfindahl-Hirschman Index)
export function calculateDiversificationIndex(holdings: { percentage: number }[]): number {
  // HHI is the sum of squared percentages (as decimals)
  const hhi = holdings.reduce((sum, coin) => sum + Math.pow(coin.percentage / 100, 2), 0);
  return hhi;
}

// Convert HHI to a diversification score (10 = perfectly diversified, 1 = single asset)
export function getDiversificationScore(hhi: number, numAssets: number): number {
  // Perfect diversification HHI = 1/N where N is number of assets
  const perfectHHI = 1 / numAssets;
  
  // Calculate how close we are to perfect diversification (inverse relationship)
  // Scale to 1-10 where 10 is perfectly diversified
  const rawScore = (1 - (hhi - perfectHHI) / (1 - perfectHHI)) * 10;
  
  // Ensure score is between 1 and 10
  return Math.min(10, Math.max(1, rawScore));
}

// Get a descriptive status for diversification score
export function getDiversificationStatus(score: number): string {
  if (score <= 3) return 'Poor';
  if (score <= 5) return 'Needs Improvement';
  if (score <= 7) return 'Adequate';
  return 'Good';
}

// Calculate risk score based on asset volatility and concentration
export function calculateRiskScore(
  volatility: number,
  diversification: number,
  riskAppetite: string
): number {
  // Base risk from volatility (0-10)
  let baseRisk = volatility;
  
  // Adjust for diversification (less diversification = higher risk)
  baseRisk += (10 - diversification) * 0.3;
  
  // Adjust for risk appetite
  const riskMultiplier = 
    riskAppetite === 'conservative' ? 0.8 :
    riskAppetite === 'moderate' ? 1.0 :
    riskAppetite === 'aggressive' ? 1.2 : 1.0;
  
  // Calculate final score and ensure it's between 1-10
  return Math.min(10, Math.max(1, baseRisk * riskMultiplier));
}

// Get a descriptive level for a risk score
export function getRiskLevel(score: number): string {
  if (score <= 3) return 'Low';
  if (score <= 5) return 'Moderate';
  if (score <= 7) return 'Moderate-High';
  if (score <= 9) return 'High';
  return 'Very High';
}

// Extract relevant text from raw OCR results
export function cleanExtractedText(text: string): string {
  // Remove common OCR artifacts
  let cleaned = text.replace(/\r\n/g, '\n')  // Normalize line endings
                     .replace(/\n{3,}/g, '\n\n')  // Remove excessive line breaks
                     .replace(/[^\x20-\x7E\n]/g, '');  // Remove non-printable characters
  
  return cleaned.trim();
}

// Parse crypto holdings from extracted text
export function parseCryptoHoldings(text: string): Array<{
  name: string;
  quantity: number;
  buyPrice: number;
}> | null {
  try {
    // This is a simplified implementation
    // In a real application, you'd use NLP or more robust parsing
    
    // Look for patterns like "Bitcoin: 0.5 BTC @ $30000"
    // or "0.5 BTC at $30000" or variations
    const lines = text.split('\n');
    const holdings = [];
    
    for (const line of lines) {
      // Skip empty lines
      if (!line.trim()) continue;
      
      // Try to match common patterns
      const coinMatch = line.match(/([A-Za-z]+(?:\s[A-Za-z]+)?)/);
      const quantityMatch = line.match(/(\d+(?:\.\d+)?)/);
      const priceMatch = line.match(/\$?(\d+(?:,\d+)*(?:\.\d+)?)/);
      
      if (coinMatch && quantityMatch && priceMatch) {
        const coin = coinMatch[1].trim();
        const quantity = parseFloat(quantityMatch[1]);
        // Remove commas for proper number parsing
        const price = parseFloat(priceMatch[1].replace(/,/g, ''));
        
        holdings.push({
          name: coin,
          quantity,
          buyPrice: price
        });
      }
    }
    
    return holdings.length > 0 ? holdings : null;
  } catch (error) {
    console.error('Error parsing crypto holdings from text:', error);
    return null;
  }
}

// Generate a unique report ID
export function generateReportId(): string {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

// Validate if a string is a valid email
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}
