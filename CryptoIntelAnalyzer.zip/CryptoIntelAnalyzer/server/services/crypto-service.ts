import axios from 'axios';

// CoinGecko API base URL
const API_BASE_URL = 'https://api.coingecko.com/api/v3';

// Get your API key from environment variables
const API_KEY = process.env.COINGECKO_API_KEY || '';

// Create axios instance with common configs
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: API_KEY ? { 'x-cg-pro-api-key': API_KEY } : {},
  timeout: 10000,
});

// Get price data for multiple coins
export async function getCoinPrices(coinIds: string[]) {
  try {
    const response = await apiClient.get('/coins/markets', {
      params: {
        vs_currency: 'usd',
        ids: coinIds.join(','),
        order: 'market_cap_desc',
        per_page: 100,
        page: 1,
        sparkline: false,
        price_change_percentage: '24h',
      },
    });

    return response.data.map((coin: any) => ({
      id: coin.id,
      symbol: coin.symbol.toUpperCase(),
      name: coin.name,
      currentPrice: coin.current_price,
      priceChange24h: coin.price_change_24h,
      priceChangePercentage24h: coin.price_change_percentage_24h,
      marketCap: coin.market_cap,
      lastUpdated: coin.last_updated,
    }));
  } catch (error) {
    console.error('Error fetching coin prices:', error);
    throw new Error('Failed to fetch cryptocurrency price data');
  }
}

// Get historical price data for a specific coin
export async function getCoinHistoricalData(coinId: string, days: number = 30, interval: string = 'daily') {
  try {
    const response = await apiClient.get(`/coins/${coinId}/market_chart`, {
      params: {
        vs_currency: 'usd',
        days: days,
        interval: interval,
      },
    });

    // Format data for frontend charts
    const prices = response.data.prices;
    const formattedData = {
      dates: prices.map((price: number[]) => new Date(price[0]).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })),
      prices: prices.map((price: number[]) => price[1]),
    };

    return formattedData;
  } catch (error) {
    console.error('Error fetching historical data:', error);
    throw new Error('Failed to fetch historical price data');
  }
}

// Search coins by query
export async function searchCoins(query: string) {
  try {
    const response = await apiClient.get('/search', {
      params: {
        query: query,
      },
    });

    return response.data.coins.slice(0, 10).map((coin: any) => ({
      id: coin.id,
      symbol: coin.symbol.toUpperCase(),
      name: coin.name,
      thumb: coin.thumb,
    }));
  } catch (error) {
    console.error('Error searching coins:', error);
    throw new Error('Failed to search for cryptocurrencies');
  }
}

// Get global market data
export async function getGlobalMarketData() {
  try {
    const response = await apiClient.get('/global');
    
    return {
      totalMarketCap: response.data.data.total_market_cap.usd,
      totalVolume: response.data.data.total_volume.usd,
      marketCapPercentage: response.data.data.market_cap_percentage,
      marketCapChangePercentage24hUsd: response.data.data.market_cap_change_percentage_24h_usd,
      activeCryptocurrencies: response.data.data.active_cryptocurrencies,
    };
  } catch (error) {
    console.error('Error fetching global market data:', error);
    throw new Error('Failed to fetch global market data');
  }
}

// Calculate portfolio value and performance
export async function calculatePortfolioMetrics(holdings: any[]) {
  try {
    // Get unique coin IDs from holdings
    const coinIds = [...new Set(holdings.map(h => h.name.toLowerCase()))];
    
    // Get current prices for all coins in portfolio
    const priceData = await getCoinPrices(coinIds);
    
    // Map of coin names to prices
    const priceMap = new Map();
    priceData.forEach(coin => {
      priceMap.set(coin.name.toLowerCase(), {
        current: coin.currentPrice,
        change24h: coin.priceChangePercentage24h,
        symbol: coin.symbol,
      });
    });
    
    // Calculate total value and performance
    let totalValue = 0;
    let totalInvested = 0;
    
    const holdingsWithMetrics = holdings.map(holding => {
      const coinData = priceMap.get(holding.name.toLowerCase());
      
      if (!coinData) {
        return {
          ...holding,
          currentValue: 0,
          performance: 0,
          symbol: holding.name.substring(0, 3).toUpperCase(),
        };
      }
      
      const currentValue = holding.quantity * coinData.current;
      const invested = holding.quantity * holding.buyPrice;
      const performance = invested > 0 ? ((currentValue - invested) / invested) * 100 : 0;
      
      totalValue += currentValue;
      totalInvested += invested;
      
      return {
        ...holding,
        currentValue,
        performance,
        symbol: coinData.symbol,
      };
    });
    
    const overallPerformance = totalInvested > 0 ? ((totalValue - totalInvested) / totalInvested) * 100 : 0;
    
    // Calculate distribution percentages
    const distribution = holdingsWithMetrics.map(h => ({
      coin: h.name,
      symbol: h.symbol,
      percentage: (h.currentValue / totalValue) * 100,
    }));
    
    // Calculate risk score (simplified version)
    // Higher concentration = higher risk
    const concentrationRisk = calculateConcentrationRisk(distribution);
    
    // Volatility based on 24h price changes
    const volatilityRisk = calculateVolatilityRisk(priceData);
    
    // Combine risks for final score (1-10 scale)
    const riskScore = Math.min(10, Math.max(1, Math.round((concentrationRisk + volatilityRisk) / 2)));
    
    // Calculate diversification score (inverse of concentration)
    const diversificationScore = Math.min(10, Math.max(1, Math.round(10 - concentrationRisk)));
    
    return {
      totalValue,
      distribution,
      overallPerformance,
      coinPerformance: holdingsWithMetrics.map(h => ({
        name: h.name,
        symbol: h.symbol,
        performance: h.performance,
      })),
      riskScore,
      riskLevel: getRiskLevel(riskScore),
      diversificationScore,
      diversificationStatus: getDiversificationStatus(diversificationScore),
    };
  } catch (error) {
    console.error('Error calculating portfolio metrics:', error);
    throw new Error('Failed to calculate portfolio metrics');
  }
}

// Helper functions
function calculateConcentrationRisk(distribution: any[]) {
  // Higher concentration = higher risk (1-10 scale)
  if (distribution.length <= 1) return 10;
  
  // Calculate Herfindahl-Hirschman Index (HHI)
  const hhi = distribution.reduce((sum, coin) => sum + Math.pow(coin.percentage / 100, 2), 0);
  
  // Scale HHI to 1-10 risk score (HHI of 1 = complete concentration, HHI of 1/n = perfect diversification)
  return Math.min(10, Math.max(1, Math.round(hhi * 10)));
}

function calculateVolatilityRisk(priceData: any[]) {
  // Higher volatility = higher risk (1-10 scale)
  if (priceData.length === 0) return 5;
  
  // Get absolute percentage changes
  const changes = priceData.map(coin => Math.abs(coin.priceChangePercentage24h || 0));
  
  // Average volatility
  const avgVolatility = changes.reduce((sum, change) => sum + change, 0) / changes.length;
  
  // Scale to 1-10 (5% daily change = score of 5)
  return Math.min(10, Math.max(1, Math.round(avgVolatility)));
}

function getRiskLevel(score: number) {
  if (score <= 3) return 'Low';
  if (score <= 6) return 'Moderate';
  if (score <= 8) return 'High';
  return 'Very High';
}

function getDiversificationStatus(score: number) {
  if (score <= 3) return 'Poor';
  if (score <= 5) return 'Needs Improvement';
  if (score <= 7) return 'Adequate';
  return 'Good';
}
