import axios from 'axios';
import { db } from '@db';
import { reports } from '@shared/schema';
import { eq } from 'drizzle-orm';

interface VerificationResult {
  success: boolean;
  message?: string;
}

import { randomBytes } from 'crypto';

// Your TRC20 USDT address that customers should pay to
const PAYMENT_ADDRESS = 'TBNwZnv9rU28cpJhJyw9D55kiPqE7qWdFd';
const REQUIRED_PAYMENT_AMOUNT = 10; // 10 USDT
const TRON_EXPLORERS = {
  api: 'https://apilist.tronscan.org/api',
  transaction: 'https://tronscan.org/#/transaction',
};

// Store pending payment sessions - in production this would be in a database
// Map of reportId to a map of sessionId to payment info (amount or memo)
const pendingPayments = new Map<string, Map<string, { amount: number, memo?: string }>>();

/**
 * Generates a unique payment amount to prevent front-running
 * Uses tiny decimal precision (4 decimal places) for uniqueness
 */
export function generateUniquePaymentAmount(reportId: string, sessionId: string): number {
  // Generate a random amount between 0.0001 and 0.0009 to add to the base amount
  // This creates a unique identifier in the tiny decimal places (10.0003, 10.0007, etc.)
  const microAmount = Math.floor(Math.random() * 9) + 1;
  // Format to 4 decimal places (e.g., 10.0003)
  const uniqueAmount = parseFloat((REQUIRED_PAYMENT_AMOUNT + microAmount / 10000).toFixed(4));
  
  // Store this unique amount for verification
  if (!pendingPayments.has(reportId)) {
    pendingPayments.set(reportId, new Map());
  }
  
  pendingPayments.get(reportId)?.set(sessionId, { amount: uniqueAmount });
  
  return uniqueAmount;
}

/**
 * Gets the unique payment amount for a specific report and session
 */
export function getUniquePaymentAmount(reportId: string, sessionId: string): number | null {
  return pendingPayments.get(reportId)?.get(sessionId)?.amount || null;
}

/**
 * Legacy function for backward compatibility
 * Generates a unique memo for a payment
 */
export function generatePaymentMemo(reportId: string, sessionId: string): string {
  // Create a unique memo using the first 6 chars of a random string
  const memo = `REP${randomBytes(3).toString('hex').toUpperCase()}`;
  
  // Store this memo alongside the unique amount
  if (!pendingPayments.has(reportId)) {
    pendingPayments.set(reportId, new Map());
  }
  
  const existingEntry = pendingPayments.get(reportId)?.get(sessionId);
  if (existingEntry) {
    existingEntry.memo = memo;
  } else {
    pendingPayments.get(reportId)?.set(sessionId, { 
      amount: generateUniquePaymentAmount(reportId, sessionId),
      memo 
    });
  }
  
  return memo;
}

/**
 * Gets the payment memo for a specific report and session
 */
export function getPaymentMemo(reportId: string, sessionId: string): string | null {
  return pendingPayments.get(reportId)?.get(sessionId)?.memo || null;
}

/**
 * Verifies a payment transaction on the Tron network
 * 
 * 1. Checks if the transaction exists on the Tron blockchain
 * 2. Verifies the transaction amount matches the user's unique payment amount
 * 3. Confirms the recipient address matches our payment address
 * 4. Ensures the transaction is confirmed
 * 5. Verifies the transaction hasn't been used for another report
 */
export async function verifyPayment(reportId: string, txid: string, sessionId: string): Promise<VerificationResult> {
  try {
    // Check if the transaction ID has already been used
    const existingPayment = await db.query.reports.findFirst({
      where: eq(reports.transactionId, txid),
    });

    if (existingPayment && existingPayment.reportId !== reportId) {
      return {
        success: false,
        message: 'This transaction has already been used for another report.'
      };
    }

    // Basic validation for transaction ID format
    const isValidTxidFormat = txid.length >= 10 && txid.trim().startsWith('T');
    
    if (!isValidTxidFormat) {
      return {
        success: false,
        message: 'Invalid transaction ID format. TRON transaction IDs typically start with "T" and are at least 10 characters long.'
      };
    }
    
    // Get the expected payment amount for this session
    const expectedAmount = getUniquePaymentAmount(reportId, sessionId);
    
    // If we don't have an amount stored, default to the memo approach or basic amount verification
    const isUsingUniqueAmount = expectedAmount !== null && expectedAmount > REQUIRED_PAYMENT_AMOUNT;

    try {
      // Make API call to TRON blockchain explorer to verify the transaction
      const response = await axios.get(`${TRON_EXPLORERS.api}/transaction-info?hash=${txid}`);
      
      if (!response.data || response.data.confirmed !== true) {
        return {
          success: false,
          message: 'Transaction not found or not confirmed on the TRON blockchain.'
        };
      }

      // For TRC20 tokens, we need to check the contract data
      const contractData = response.data.trc20TransferInfo || [];
      
      // Find the USDT transfer to our address
      const usdtTransfer = contractData.find((transfer: any) => 
        transfer.to_address === PAYMENT_ADDRESS && 
        transfer.symbol === 'USDT'
      );
      
      if (!usdtTransfer) {
        return {
          success: false,
          message: `No USDT transfer to ${PAYMENT_ADDRESS} found in this transaction.`
        };
      }

      // Check the transfer amount (TRON returns amount with decimals)
      const paymentAmount = parseFloat(usdtTransfer.amount_str) / 1000000; // Convert from Wei to USDT
      
      // Check if the amount matches our expected unique amount (with tiny margin for error)
      // We need very precise checking since we're using 4 decimal places
      const acceptableMargin = 0.00005; // Allow a very tiny difference for rounding
      
      if (expectedAmount && Math.abs(paymentAmount - expectedAmount) <= acceptableMargin) {
        // Amount matches the unique amount for this session to 4 decimal places!
        console.log(`Verified payment via unique amount: ${paymentAmount} matches expected ${expectedAmount}`);
      } else {
        // If no exact match, check if it's at least the minimum amount
        if (paymentAmount < REQUIRED_PAYMENT_AMOUNT) {
          return {
            success: false,
            message: `Payment amount (${paymentAmount.toFixed(4)} USDT) is less than the required ${REQUIRED_PAYMENT_AMOUNT} USDT.`
          };
        }
        
        // If it's not the exact unique amount for this session, it may belong to another user
        if (expectedAmount) {
          console.log(`Payment amount ${paymentAmount} doesn't exactly match expected ${expectedAmount}, but meets minimum requirement`);
        }
      }
      
      // Check if the transaction is confirmed
      if (response.data.confirmations < 1) {
        return {
          success: false,
          message: 'Transaction has not been confirmed yet. Please wait for blockchain confirmation.'
        };
      }

    } catch (error) {
      console.error("TRON API error:", error);
      return {
        success: false,
        message: 'Unable to verify transaction on the blockchain. Please try again later or contact support.'
      };
    }

    // Update the report's payment status
    await db
      .update(reports)
      .set({
        paymentStatus: 'verified',
        transactionId: txid,
      })
      .where(eq(reports.reportId, reportId));

    return {
      success: true
    };
  } catch (error) {
    console.error('Payment verification error:', error);
    return {
      success: false,
      message: 'An error occurred during payment verification.'
    };
  }
}

/**
 * Retrieves the payment status for a report
 */
export async function getPaymentStatus(reportId: string): Promise<string> {
  try {
    const report = await db.query.reports.findFirst({
      where: eq(reports.reportId, reportId),
    });

    return report?.paymentStatus || 'unpaid';
  } catch (error) {
    console.error('Error retrieving payment status:', error);
    return 'unknown';
  }
}

/**
 * Gets transaction details from the TRON blockchain
 * This is useful for displaying transaction details to users
 */
export async function getTransactionDetails(txid: string): Promise<any> {
  try {
    const response = await axios.get(`${TRON_EXPLORERS.api}/transaction-info?hash=${txid}`);
    
    if (!response.data) {
      return null;
    }
    
    // For TRC20 tokens, extract the relevant transfer information
    const contractData = response.data.trc20TransferInfo || [];
    const usdtTransfer = contractData.find((transfer: any) => 
      transfer.symbol === 'USDT'
    );
    
    if (!usdtTransfer) {
      return {
        txid: txid,
        confirmed: response.data.confirmed,
        timestamp: response.data.timestamp,
        confirmations: response.data.confirmations,
        explorerUrl: `${TRON_EXPLORERS.transaction}/${txid}`,
        transferInfo: null
      };
    }
    
    return {
      txid: txid,
      confirmed: response.data.confirmed,
      timestamp: response.data.timestamp,
      confirmations: response.data.confirmations,
      explorerUrl: `${TRON_EXPLORERS.transaction}/${txid}`,
      transferInfo: {
        from: usdtTransfer.from_address,
        to: usdtTransfer.to_address,
        symbol: usdtTransfer.symbol,
        amount: parseFloat(usdtTransfer.amount_str) / 1000000, // Convert from Wei to USDT
      }
    };
  } catch (error) {
    console.error('Error fetching transaction details:', error);
    return null;
  }
}