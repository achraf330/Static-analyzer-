import { apiRequest } from "@/lib/queryClient";

interface CoinPrice {
  id: string;
  symbol: string;
  name: string;
  currentPrice: number;
  priceChange24h: number;
  priceChangePercentage24h: number;
  marketCap: number;
  lastUpdated: string;
}

interface PriceHistory {
  dates: string[];
  prices: number[];
}

// Function to fetch current prices for multiple coins
export async function fetchCoinPrices(coinIds: string[]): Promise<CoinPrice[]> {
  try {
    // No need to call the API directly, use our server as a proxy
    const response = await apiRequest('GET', `/api/crypto/prices?coins=${coinIds.join(',')}`);
    return await response.json();
  } catch (error) {
    console.error('Error fetching coin prices:', error);
    throw error;
  }
}

// Function to fetch historical price data for a specific coin
export async function fetchCoinHistory(
  coinId: string,
  days: number = 30,
  interval: string = 'daily'
): Promise<PriceHistory> {
  try {
    const response = await apiRequest(
      'GET',
      `/api/crypto/history?coin=${coinId}&days=${days}&interval=${interval}`
    );
    return await response.json();
  } catch (error) {
    console.error('Error fetching coin history:', error);
    throw error;
  }
}

// Function to search for coins by name or symbol
export async function searchCoins(query: string): Promise<any[]> {
  try {
    const response = await apiRequest('GET', `/api/crypto/search?query=${query}`);
    return await response.json();
  } catch (error) {
    console.error('Error searching coins:', error);
    throw error;
  }
}

// Function to get global crypto market data
export async function getGlobalMarketData(): Promise<any> {
  try {
    const response = await apiRequest('GET', '/api/crypto/global');
    return await response.json();
  } catch (error) {
    console.error('Error fetching global market data:', error);
    throw error;
  }
}
