import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(value);
}

export function formatPercentage(value: number): string {
  const sign = value >= 0 ? '+' : '';
  return `${sign}${value.toFixed(1)}%`;
}

export const riskLevels = {
  conservative: "Low risk, stable returns",
  moderate: "Balanced risk and returns",
  aggressive: "High risk, high potential returns"
};

export const investmentTimeframes = {
  short: "Short-term (< 1 year)",
  medium: "Medium-term (1-3 years)",
  long: "Long-term (3+ years)"
};

export const investmentGoals = {
  preservation: "Capital Preservation",
  income: "Regular Income",
  growth: "Capital Growth",
  speculation: "Speculation"
};
