import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

interface PortfolioScoreProps {
  score: number;
  riskLevel: string;
  diversificationStatus: string;
}

export default function PortfolioScore({ score, riskLevel, diversificationStatus }: PortfolioScoreProps) {
  // Determine score color based on the value
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600 dark:text-green-400';
    if (score >= 60) return 'text-blue-600 dark:text-blue-400';
    if (score >= 40) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  // Determine progress color based on the value
  const getProgressColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-blue-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  // Get risk level badge color
  const getRiskBadgeColor = (riskLevel: string) => {
    switch (riskLevel.toLowerCase()) {
      case 'low':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 border-green-300 dark:border-green-800';
      case 'moderate':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400 border-blue-300 dark:border-blue-800';
      case 'moderate-high':
      case 'high':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400 border-yellow-300 dark:border-yellow-800';
      case 'very high':
        return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 border-red-300 dark:border-red-800';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400 border-gray-300 dark:border-gray-800';
    }
  };

  // Get diversification badge color
  const getDiversificationBadgeColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'good':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 border-green-300 dark:border-green-800';
      case 'adequate':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400 border-blue-300 dark:border-blue-800';
      case 'needs improvement':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400 border-yellow-300 dark:border-yellow-800';
      case 'poor':
        return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 border-red-300 dark:border-red-800';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400 border-gray-300 dark:border-gray-800';
    }
  };

  return (
    <Card className="mb-8 border-2">
      <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/40 dark:to-purple-950/40">
        <CardTitle className="text-xl font-bold">Free Portfolio Score</CardTitle>
        <CardDescription>
          Your portfolio has been analyzed based on coin quality, diversification, and risk factors.
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="flex flex-col items-center justify-center mb-6">
          <div className={`text-6xl font-bold mb-2 ${getScoreColor(score)}`}>
            {score}
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">Portfolio Score (out of 100)</div>
          <Progress 
            value={score} 
            className="h-3 w-full"
            indicatorClassName={getProgressColor(score)}
          />
        </div>

        <div className="grid grid-cols-2 gap-4 mt-6">
          <div className="flex flex-col items-center p-4 border rounded-md bg-gray-50 dark:bg-gray-900/50">
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">Risk Level</div>
            <Badge variant="outline" className={getRiskBadgeColor(riskLevel)}>
              {riskLevel}
            </Badge>
          </div>
          <div className="flex flex-col items-center p-4 border rounded-md bg-gray-50 dark:bg-gray-900/50">
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">Diversification</div>
            <Badge variant="outline" className={getDiversificationBadgeColor(diversificationStatus)}>
              {diversificationStatus}
            </Badge>
          </div>
        </div>

        <div className="mt-6 p-4 border rounded-md bg-blue-50 dark:bg-blue-900/20 text-sm text-gray-600 dark:text-gray-300">
          <p className="font-semibold mb-2">What does this score mean?</p>
          <p>
            Your free portfolio score indicates the overall health of your crypto investments based on:
          </p>
          <ul className="list-disc list-inside mt-2 ml-2">
            <li>Quality of cryptocurrencies in your portfolio</li>
            <li>Level of diversification across different assets</li>
            <li>Match between your risk appetite and portfolio composition</li>
          </ul>
          <p className="mt-2">
            <strong>Want detailed insights?</strong> Unlock your full report for just 10 USDT to see specific recommendations for improving your portfolio.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}