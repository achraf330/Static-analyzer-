import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Copy, CheckCircle, AlertCircle, ExternalLink, Loader2, ArrowRight, Info } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

interface PaymentSectionProps {
  reportId: string;
  paymentStatus: string;
  onPaymentVerified: () => void;
}

interface PaymentDetails {
  address: string;
  amount: number;
  currency: string;
  network: string;
  memo?: string;
  sessionId?: string;
  instructions?: string;
}

interface TransactionDetails {
  txid: string;
  confirmed: boolean;
  timestamp: number;
  confirmations: number;
  explorerUrl: string;
  transferInfo: {
    from: string;
    to: string;
    symbol: string;
    amount: number;
  } | null;
}

export default function PaymentSection({ reportId, paymentStatus, onPaymentVerified }: PaymentSectionProps) {
  const { toast } = useToast();
  const [txid, setTxid] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isCheckingTx, setIsCheckingTx] = useState(false);
  const [verificationError, setVerificationError] = useState('');
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails | null>(null);
  const [txDetails, setTxDetails] = useState<TransactionDetails | null>(null);
  const [isLoadingPaymentDetails, setIsLoadingPaymentDetails] = useState(true);

  // Fetch payment details from API
  useEffect(() => {
    async function fetchPaymentDetails() {
      try {
        setIsLoadingPaymentDetails(true);
        // Use the new endpoint that generates a unique session and memo
        const response = await fetch(`/api/payment/details/${reportId}`);
        if (response.ok) {
          const data = await response.json();
          setPaymentDetails(data);
          
          // Save the session ID for verification
          if (data.sessionId) {
            localStorage.setItem(`payment_session_${reportId}`, data.sessionId);
          }
          
          // Alert the user about the memo if it exists
          if (data.memo) {
            toast({
              title: 'Important Payment Info',
              description: `Your unique payment reference is: ${data.memo}. Include this in your transaction.`,
              duration: 10000, // Show for longer period
            });
          }
        } else {
          // Fallback if API fails - use the legacy endpoint
          const legacyResponse = await fetch('/api/payment/address');
          if (legacyResponse.ok) {
            const legacyData = await legacyResponse.json();
            setPaymentDetails(legacyData);
          } else {
            // Ultimate fallback
            setPaymentDetails({
              address: 'TBNwZnv9rU28cpJhJyw9D55kiPqE7qWdFd',
              amount: 10,
              currency: 'USDT',
              network: 'TRC20'
            });
          }
        }
      } catch (error) {
        console.error("Error fetching payment details:", error);
        // Fallback
        setPaymentDetails({
          address: 'TBNwZnv9rU28cpJhJyw9D55kiPqE7qWdFd',
          amount: 10,
          currency: 'USDT',
          network: 'TRC20'
        });
      } finally {
        setIsLoadingPaymentDetails(false);
      }
    }
    
    fetchPaymentDetails();
  }, []);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied to clipboard',
      description: 'The payment address has been copied to your clipboard.',
    });
  };

  // Check transaction details on the blockchain
  const checkTransaction = async () => {
    if (!txid.trim()) {
      setVerificationError('Please enter a transaction ID.');
      return;
    }

    setIsCheckingTx(true);
    setVerificationError('');
    setTxDetails(null);

    try {
      const response = await fetch(`/api/payment/transaction/${txid.trim()}`);
      
      if (!response.ok) {
        throw new Error('Transaction not found on the blockchain');
      }
      
      const data = await response.json();
      setTxDetails(data);
      
      // Show a success message
      toast({
        title: 'Transaction found!',
        description: 'We found your transaction on the blockchain.',
      });
      
    } catch (error) {
      console.error('Error checking transaction:', error);
      setVerificationError('Transaction not found or invalid. Please check the transaction ID.');
    } finally {
      setIsCheckingTx(false);
    }
  };

  const handleVerifyPayment = async () => {
    if (!txid.trim()) {
      setVerificationError('Please enter a transaction ID.');
      return;
    }

    setIsVerifying(true);
    setVerificationError('');

    try {
      // Get the session ID from localStorage (or use the one from payment details)
      const sessionId = 
        localStorage.getItem(`payment_session_${reportId}`) || 
        paymentDetails?.sessionId || 
        `session_${Date.now()}`;

      const response = await fetch('/api/payment/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          reportId,
          txid: txid.trim(),
          sessionId: sessionId,
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: 'Payment verified!',
          description: 'Your payment has been verified. You can now access your full report.',
        });
        onPaymentVerified();
      } else {
        setVerificationError(data.message || 'Unable to verify payment. Please check your transaction ID.');
      }
    } catch (error) {
      setVerificationError('An error occurred during verification. Please try again.');
      console.error('Payment verification error:', error);
    } finally {
      setIsVerifying(false);
    }
  };
  
  // Format date from Unix timestamp
  const formatDate = (timestamp: number) => {
    if (!timestamp) return 'Unknown';
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  if (paymentStatus === 'verified') {
    return (
      <Card className="mb-8 border-2 border-green-500/50 bg-green-50 dark:bg-green-900/10">
        <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/40 dark:to-emerald-950/40">
          <CardTitle className="text-xl font-bold text-green-700 dark:text-green-400 flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Investment in Clarity Confirmed!
          </CardTitle>
          <CardDescription>
            Thank you for taking this important step toward reducing confusion and stress in your crypto journey. Your full portfolio analysis is now available.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <p className="text-sm text-green-700/80 dark:text-green-400/80">
            We've unlocked detailed insights that will transform how you approach your crypto investments. Scroll down to see your complete report and downloadable PDF.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-8 border-2">
      <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/40 dark:to-purple-950/40">
        <CardTitle className="text-xl font-bold">Stop the Crypto Confusion - Unlock Clarity</CardTitle>
        <CardDescription>
          For just the price of a cup of coffee ({paymentDetails?.amount || 10} {paymentDetails?.currency || 'USDT'}), transform stress into confidence with expert insights tailored to your portfolio.
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="flex flex-col space-y-6">
          <div className="p-4 border rounded-md bg-blue-50 dark:bg-blue-900/20">
            <h3 className="font-semibold mb-2 text-blue-700 dark:text-blue-400">From Confusion to Clarity:</h3>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>Transform uncertainty into confident decision-making</li>
              <li>Detailed coin-by-coin performance analysis with actionable insights</li>
              <li>Personalized risk assessment to reduce investment stress</li>
              <li>Market trend insights specific to your unique portfolio</li>
              <li>Expert rebalancing recommendations for optimized returns</li>
              <li>Opportunities you might be missing in this volatile market</li>
              <li>Downloadable PDF report that pays for itself many times over</li>
            </ul>
            <p className="mt-3 text-sm italic text-blue-700/70 dark:text-blue-400/70">
              All for less than a cup of coffee — invest in clarity today.
            </p>
          </div>

          <div className="p-5 border rounded-md space-y-4 bg-gradient-to-br from-indigo-50/50 to-purple-50/50 dark:from-indigo-950/40 dark:to-purple-950/40">
            <h3 className="font-semibold text-lg mb-2">Payment Instructions</h3>
            
            <div className="bg-white dark:bg-gray-900 p-4 rounded-md shadow-sm space-y-4">
              {/* Unique amount with explanation */}
              <div className="border-b pb-4 border-indigo-100 dark:border-indigo-900/50">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-indigo-700 dark:text-indigo-300">Amount to Send:</span>
                  <div className="flex gap-2 items-center">
                    <span className="font-bold text-xl font-mono tracking-tight text-indigo-600 dark:text-indigo-300">
                      {paymentDetails?.amount.toFixed(4) || '10.0000'} {paymentDetails?.currency || 'USDT'}
                    </span>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="h-7 px-2 text-indigo-600 dark:text-indigo-400"
                      onClick={() => copyToClipboard(paymentDetails?.amount.toFixed(4) || '10.0000')}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <p className="text-xs text-indigo-600/80 dark:text-indigo-400/80 bg-indigo-50 dark:bg-indigo-950/50 p-2 rounded-sm">
                  <strong>Important:</strong> Send <strong>EXACTLY</strong> this amount to create your unique payment signature. The digits after the decimals (like 10.000<strong>3</strong>) prevent transaction front-running.
                </p>
              </div>
              
              {/* Address */}
              <div className="space-y-2">
                <span className="text-sm font-medium text-indigo-700 dark:text-indigo-300">Send to this address:</span>
                <div className="flex">
                  <Input 
                    value={paymentDetails?.address || 'TBNwZnv9rU28cpJhJyw9D55kiPqE7qWdFd'} 
                    readOnly 
                    className="rounded-r-none border-r-0 font-mono text-sm bg-gray-50 dark:bg-gray-900"
                  />
                  <Button 
                    variant="outline" 
                    className="rounded-l-none" 
                    onClick={() => copyToClipboard(paymentDetails?.address || 'TBNwZnv9rU28cpJhJyw9D55kiPqE7qWdFd')}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex gap-1 items-center text-xs text-gray-600 dark:text-gray-400">
                  <AlertCircle className="h-3 w-3" />
                  <span>Only send {paymentDetails?.currency || 'USDT'} on the {paymentDetails?.network || 'TRC20'} network.</span>
                </div>
              </div>
            </div>
            
            {/* Tips for users */}
            <div className="bg-white dark:bg-gray-900 p-3 rounded-md shadow-sm">
              <h4 className="text-sm font-medium text-indigo-700 dark:text-indigo-300 mb-2 flex items-center gap-1">
                <Info className="h-3 w-3" /> Tips for sending payments
              </h4>
              <ul className="space-y-1 text-xs text-gray-600 dark:text-gray-400">
                <li className="flex gap-1">
                  <ArrowRight className="h-3 w-3 text-indigo-500 shrink-0 mt-0.5" />
                  <span>Double-check the payment amount – must include all decimal places (e.g., 10.000<strong>3</strong>)</span>
                </li>
                <li className="flex gap-1">
                  <ArrowRight className="h-3 w-3 text-indigo-500 shrink-0 mt-0.5" />
                  <span>Ensure you're using the TRC20 network in your wallet</span>
                </li>
                <li className="flex gap-1">
                  <ArrowRight className="h-3 w-3 text-indigo-500 shrink-0 mt-0.5" />
                  <span>After sending, obtain your transaction ID (TXID) from your wallet</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="p-4 border rounded-md space-y-4">
            <h3 className="font-semibold">Verify your payment:</h3>
            <div className="flex flex-col space-y-2">
              <Label htmlFor="txid">Transaction ID (TXID):</Label>
              <div className="flex gap-2">
                <Input 
                  id="txid" 
                  value={txid} 
                  onChange={(e) => setTxid(e.target.value)} 
                  placeholder="Enter your TXID from the transaction"
                  className="font-mono text-sm"
                />
                <Button
                  variant="outline"
                  onClick={checkTransaction}
                  disabled={isCheckingTx || !txid.trim()}
                >
                  {isCheckingTx ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Check'}
                </Button>
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400">
                After sending payment, paste your transaction ID (TXID) here and click "Check" to verify it on the blockchain.
              </div>
            </div>
            
            {/* Transaction Details Panel */}
            {txDetails && (
              <div className="mt-3 p-3 border rounded-md bg-gray-50 dark:bg-gray-900/40">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-sm">Transaction Details</h4>
                  <Badge variant={txDetails.confirmed ? "secondary" : "outline"}>
                    {txDetails.confirmed ? 'Confirmed' : 'Pending'}
                  </Badge>
                </div>
                
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Time:</span>
                    <span>{formatDate(txDetails.timestamp)}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Confirmations:</span>
                    <span>{txDetails.confirmations}</span>
                  </div>
                  
                  {txDetails.transferInfo && (
                    <>
                      <Separator className="my-2" />
                      <div className="flex justify-between">
                        <span className="text-gray-500 dark:text-gray-400">From:</span>
                        <span className="font-mono truncate max-w-[200px]" title={txDetails.transferInfo.from}>
                          {txDetails.transferInfo.from.substring(0, 8)}...{txDetails.transferInfo.from.substring(txDetails.transferInfo.from.length - 8)}
                        </span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-gray-500 dark:text-gray-400">To:</span>
                        <span className="font-mono truncate max-w-[200px]" title={txDetails.transferInfo.to}>
                          {txDetails.transferInfo.to.substring(0, 8)}...{txDetails.transferInfo.to.substring(txDetails.transferInfo.to.length - 8)}
                        </span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-gray-500 dark:text-gray-400">Amount:</span>
                        <span className="font-semibold">
                          {txDetails.transferInfo.amount} {txDetails.transferInfo.symbol}
                        </span>
                      </div>
                    </>
                  )}
                  
                  <div className="mt-2 pt-2 border-t">
                    <a 
                      href={txDetails.explorerUrl} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-blue-600 dark:text-blue-400 inline-flex items-center gap-1 text-xs"
                    >
                      View on TRON Explorer <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>
              </div>
            )}
            
            {verificationError && (
              <div className="flex items-center gap-2 text-sm text-red-600 dark:text-red-400 mt-2">
                <AlertCircle className="h-4 w-4" />
                {verificationError}
              </div>
            )}
            
            <Button 
              className="w-full" 
              onClick={handleVerifyPayment} 
              disabled={isVerifying || !txid.trim() || txid.length < 10}
            >
              {isVerifying ? 'Verifying...' : 'Verify Payment'}
            </Button>
            
            {/* If transaction is found but not confirmed */}
            {txDetails && !txDetails.confirmed && (
              <div className="text-center text-amber-600 dark:text-amber-400 text-sm flex items-center justify-center gap-2 mt-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Waiting for blockchain confirmation...
              </div>
            )}
            
            {/* If amount is incorrect */}
            {txDetails && txDetails.transferInfo && 
             txDetails.transferInfo.amount < (paymentDetails?.amount || 10) && (
              <div className="text-center text-red-600 dark:text-red-400 text-sm flex items-center justify-center gap-2 mt-2">
                <AlertCircle className="h-4 w-4" />
                Amount sent ({txDetails.transferInfo.amount} USDT) is less than required ({paymentDetails?.amount || 10} USDT).
              </div>
            )}
            
            <div className="mt-2 text-center text-xs text-gray-500 dark:text-gray-400">
              <p>Example TXID format: <span className="font-mono">TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE</span></p>
              <p className="mt-1">You can find your TXID in your TRON wallet's transaction history after sending payment.</p>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="bg-gray-50 dark:bg-gray-900/30 border-t text-xs text-gray-500 dark:text-gray-400 flex flex-col items-start space-y-1">
        <div className="flex items-center gap-1">
          <span>Need help with your payment?</span>
          <a href="mailto:support@cryptoanalyzer.com" className="text-blue-600 dark:text-blue-400 inline-flex items-center gap-1">
            Contact support
            <ExternalLink className="h-3 w-3" />
          </a>
        </div>
        <div>Your data is securely processed, and your report will be available immediately after payment verification.</div>
      </CardFooter>
    </Card>
  );
}