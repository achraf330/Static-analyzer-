import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Brain, Check, FileText, RotateCw } from "lucide-react";

interface ProcessingSectionProps {
  progress: {
    percentage: number;
    step: string;
    steps: {
      extracting: { status: string };
      analyzing: { status: string };
      generating: { status: string };
    };
  };
}

export default function ProcessingSection({ progress }: ProcessingSectionProps) {
  const getStepIcon = (status: string) => {
    if (status === "complete") return <Check className="h-4 w-4" />;
    if (status === "processing") return <RotateCw className="h-4 w-4 animate-spin" />;
    return null;
  };

  const getStatusColor = (status: string) => {
    if (status === "complete") return "bg-green-500/10 text-green-500";
    if (status === "processing") return "bg-primary/10 text-primary";
    return "bg-muted text-muted-foreground";
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center p-3 bg-muted/30 rounded-full text-primary">
            <Brain className="h-10 w-10" />
          </div>
          <h2 className="text-xl font-semibold">Analyzing Your Portfolio</h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Our AI is analyzing your crypto holdings and market data to generate comprehensive insights and recommendations.
          </p>
          
          <div className="max-w-lg mx-auto mt-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>
                  {progress.step === "extracting" && "Collecting market data..."}
                  {progress.step === "analyzing" && "Analyzing portfolio performance..."}
                  {progress.step === "generating" && "Generating recommendations..."}
                  {progress.step === "complete" && "Analysis complete!"}
                </span>
                <span>{progress.percentage}%</span>
              </div>
              <Progress value={progress.percentage} className="h-2" />
            </div>
            
            <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className={`rounded-md p-4 text-center bg-muted/30`}>
                <div className={`inline-flex items-center justify-center p-2 rounded-full mb-2 ${getStatusColor(progress.steps.extracting.status)}`}>
                  {getStepIcon(progress.steps.extracting.status) || <FileText className="h-4 w-4" />}
                </div>
                <h4 className="text-sm font-medium">Data Extraction</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  {progress.steps.extracting.status === "complete" && "Complete"}
                  {progress.steps.extracting.status === "processing" && "In progress"}
                  {progress.steps.extracting.status === "idle" && "Waiting"}
                </p>
              </div>
              
              <div className={`rounded-md p-4 text-center bg-muted/30`}>
                <div className={`inline-flex items-center justify-center p-2 rounded-full mb-2 ${getStatusColor(progress.steps.analyzing.status)}`}>
                  {getStepIcon(progress.steps.analyzing.status) || <RotateCw className="h-4 w-4" />}
                </div>
                <h4 className="text-sm font-medium">Market Analysis</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  {progress.steps.analyzing.status === "complete" && "Complete"}
                  {progress.steps.analyzing.status === "processing" && "In progress"}
                  {progress.steps.analyzing.status === "idle" && "Waiting"}
                </p>
              </div>
              
              <div className={`rounded-md p-4 text-center bg-muted/30`}>
                <div className={`inline-flex items-center justify-center p-2 rounded-full mb-2 ${getStatusColor(progress.steps.generating.status)}`}>
                  {getStepIcon(progress.steps.generating.status) || <FileText className="h-4 w-4" />}
                </div>
                <h4 className="text-sm font-medium">Report Generation</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  {progress.steps.generating.status === "complete" && "Complete"}
                  {progress.steps.generating.status === "processing" && "In progress"}
                  {progress.steps.generating.status === "idle" && "Waiting"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
