import { useState } from "react";
import { useFieldArray, UseFormReturn } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash } from "lucide-react";
import { FormMessage } from "@/components/ui/form";
import { PortfolioFormData } from "@/components/portfolio-form";

interface CryptoHoldingsFormProps {
  form: UseFormReturn<PortfolioFormData>;
}

export default function CryptoHoldingsForm({ form }: CryptoHoldingsFormProps) {
  const { control, register, formState: { errors } } = form;
  
  const { fields, append, remove } = useFieldArray({
    control,
    name: "holdings",
  });

  const addHolding = () => {
    append({
      name: "",
      quantity: 0,
      buyPrice: 0,
    });
  };

  return (
    <div className="bg-muted/30 rounded-md p-4 space-y-4">
      {fields.map((field, index) => (
        <div key={field.id} className="grid grid-cols-12 gap-3 items-center crypto-holding">
          <div className="col-span-12 sm:col-span-3">
            <Label className="text-xs text-muted-foreground mb-1 block">Coin Name</Label>
            <div className="flex bg-muted border border-input rounded-md h-10">
              <Input
                type="text"
                className="flex-1 h-full px-3 py-2 text-sm border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                {...register(`holdings.${index}.name`)}
              />
            </div>
            {errors.holdings?.[index]?.name && (
              <FormMessage>{errors.holdings[index]?.name?.message}</FormMessage>
            )}
          </div>
          
          <div className="col-span-12 sm:col-span-3">
            <Label className="text-xs text-muted-foreground mb-1 block">Quantity (number of coins)</Label>
            <div className="flex bg-muted border border-input rounded-md h-10">
              <Input
                type="number"
                step="0.0001"
                className="flex-1 h-full px-3 py-2 text-sm border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                {...register(`holdings.${index}.quantity`, { valueAsNumber: true })}
              />
            </div>
            {errors.holdings?.[index]?.quantity && (
              <FormMessage>{errors.holdings[index]?.quantity?.message}</FormMessage>
            )}
          </div>
          
          <div className="col-span-10 sm:col-span-5">
            <Label className="text-xs text-muted-foreground mb-1 block">Average Buy Price (USD)</Label>
            <div className="flex bg-muted border border-input rounded-md h-10">
              <span className="flex items-center pl-3 text-sm text-muted-foreground">$</span>
              <Input
                type="number"
                step="0.01"
                className="flex-1 h-full px-3 py-2 text-sm border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                {...register(`holdings.${index}.buyPrice`, { valueAsNumber: true })}
              />
            </div>
            {errors.holdings?.[index]?.buyPrice && (
              <FormMessage>{errors.holdings[index]?.buyPrice?.message}</FormMessage>
            )}
          </div>
          
          <div className="col-span-2 sm:col-span-1 flex justify-end items-end h-full">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-10 w-10 rounded-md border border-input bg-muted text-muted-foreground hover:bg-destructive hover:text-destructive-foreground transition-colors"
              onClick={() => fields.length > 1 && remove(index)}
              disabled={fields.length <= 1}
            >
              <Trash className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ))}
      
      <Button
        type="button"
        variant="ghost"
        className="text-primary"
        onClick={addHolding}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
          <path d="M12 5v14M5 12h14"></path>
        </svg>
        Add Another Coin
      </Button>
    </div>
  );
}
