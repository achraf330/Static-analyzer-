import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import CryptoHoldingsForm from "@/components/crypto-holdings-form";
import FileUpload from "@/components/file-upload";
import { investmentGoals, investmentTimeframes, riskLevels } from "@/lib/utils";

const formSchema = z.object({
  client: z.object({
    name: z.string().min(2, "Name must be at least 2 characters"),
    email: z.string().email("Please enter a valid email address"),
  }),
  profile: z.object({
    timeframe: z.string().min(1, "Please select a timeframe"),
    risk: z.string().min(1, "Please select a risk level"),
    goal: z.string().min(1, "Please select an investment goal"),
    notes: z.string().optional(),
  }),
  holdings: z.array(
    z.object({
      name: z.string().min(1, "Coin name is required"),
      quantity: z.coerce.number().positive("Quantity must be positive"),
      buyPrice: z.coerce.number().positive("Buy price must be positive"),
    })
  ).min(1, "At least one crypto holding is required"),
  files: z.array(z.any()).optional(),
});

export type PortfolioFormData = z.infer<typeof formSchema>;

interface PortfolioFormProps {
  onSubmit: (data: FormData) => void;
}

export default function PortfolioForm({ onSubmit }: PortfolioFormProps) {
  const [files, setFiles] = useState<File[]>([]);

  const form = useForm<PortfolioFormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      client: {
        name: "",
        email: "",
      },
      profile: {
        timeframe: "",
        risk: "",
        goal: "",
        notes: "",
      },
      holdings: [
        {
          name: "",
          quantity: 0,
          buyPrice: 0,
        },
      ],
      files: [],
    },
  });

  const handleSubmit = (data: PortfolioFormData) => {
    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    
    // Add files to form data
    files.forEach((file, index) => {
      formData.append(`file-${index}`, file);
    });

    onSubmit(formData);
  };

  return (
    <Card className="mb-10">
      <CardHeader className="border-b border-border">
        <CardTitle>Create Your Crypto Portfolio Analysis</CardTitle>
        <CardDescription>Fill in your details and crypto holdings for a personalized report.</CardDescription>
      </CardHeader>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)}>
          <CardContent className="p-6 space-y-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <h3 className="text-base font-medium flex items-center">
                <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs mr-2">1</span>
                Personal Information
              </h3>
              
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="client.name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="client.email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input placeholder="john.doe@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            {/* Investment Profile */}
            <div className="space-y-4 pt-4">
              <Separator className="mb-4" />
              <h3 className="text-base font-medium flex items-center">
                <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs mr-2">2</span>
                Investment Profile
              </h3>
              
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <FormField
                  control={form.control}
                  name="profile.timeframe"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Investment Timeframe</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select timeframe" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Object.entries(investmentTimeframes).map(([key, value]) => (
                            <SelectItem key={key} value={key}>{value}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="profile.risk"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Risk Appetite</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select risk level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Object.entries(riskLevels).map(([key, value]) => (
                            <SelectItem key={key} value={key}>{key.charAt(0).toUpperCase() + key.slice(1)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="profile.goal"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Investment Goal</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select goal" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Object.entries(investmentGoals).map(([key, value]) => (
                            <SelectItem key={key} value={key}>{value}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="profile.notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Additional Notes (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Any specific information about your investment strategy or goals..." 
                        className="resize-none" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            {/* Crypto Holdings */}
            <div className="space-y-4 pt-4">
              <Separator className="mb-4" />
              <h3 className="text-base font-medium flex items-center">
                <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs mr-2">3</span>
                Crypto Holdings
              </h3>
              
              <CryptoHoldingsForm form={form} />
            </div>
            
            {/* File Upload */}
            <div className="space-y-4 pt-4">
              <Separator className="mb-4" />
              <h3 className="text-base font-medium flex items-center">
                <span className="flex items-center justify-center h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs mr-2">4</span>
                Upload Portfolio Data (Optional)
              </h3>
              
              <FileUpload files={files} setFiles={setFiles} />
            </div>
          </CardContent>
          
          <CardFooter className="p-6 border-t border-border flex flex-col sm:flex-row gap-3 justify-end">
            <Button type="button" variant="outline">
              Save Draft
            </Button>
            <Button type="submit">
              Generate Analysis Report
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
