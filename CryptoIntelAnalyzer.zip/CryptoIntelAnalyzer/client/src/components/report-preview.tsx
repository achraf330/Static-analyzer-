import { useState, useEffect, useRef } from "react";
import { Share2, Download, ArrowUp, ArrowDown, Lightbulb, BarChart, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { formatCurrency, formatPercentage } from "@/lib/utils";
import Chart from "chart.js/auto";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ReportProps {
  report: any;
}

export default function ReportPreview({ report }: ReportProps) {
  const [isClient, setIsClient] = useState(false);
  const portfolioChartRef = useRef<HTMLCanvasElement>(null);
  const priceChartRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (isClient && portfolioChartRef.current && report?.portfolio?.distribution) {
      const ctx = portfolioChartRef.current.getContext('2d');
      if (!ctx) return;

      const colors = [
        'hsl(var(--chart-1))',
        'hsl(var(--chart-2))',
        'hsl(var(--chart-3))',
        'hsl(var(--chart-4))',
        'hsl(var(--chart-5))',
      ];

      const chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: report.portfolio.distribution.map((item: any) => item.coin),
          datasets: [{
            data: report.portfolio.distribution.map((item: any) => item.percentage),
            backgroundColor: colors,
            borderColor: 'hsl(var(--card))',
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                color: 'hsl(var(--foreground))',
                padding: 20,
                font: {
                  size: 12
                }
              }
            }
          },
          cutout: '70%'
        }
      });

      return () => {
        chart.destroy();
      };
    }
  }, [isClient, report?.portfolio?.distribution]);

  useEffect(() => {
    if (isClient && priceChartRef.current && report?.marketData?.priceHistory) {
      const ctx = priceChartRef.current.getContext('2d');
      if (!ctx) return;

      const chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: report.marketData.priceHistory.dates,
          datasets: [{
            label: 'BTC Price (USD)',
            data: report.marketData.priceHistory.prices,
            borderColor: 'hsl(var(--primary))',
            backgroundColor: 'hsla(var(--primary), 0.1)',
            tension: 0.3,
            fill: true
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                label: function(context) {
                  return formatCurrency(context.raw as number);
                }
              }
            }
          },
          scales: {
            x: {
              grid: {
                color: 'rgba(255, 255, 255, 0.05)'
              },
              ticks: {
                color: 'hsl(var(--muted-foreground))',
                maxRotation: 0,
                autoSkip: true,
                maxTicksLimit: 7
              }
            },
            y: {
              grid: {
                color: 'rgba(255, 255, 255, 0.05)'
              },
              ticks: {
                color: 'hsl(var(--muted-foreground))',
                callback: function(value) {
                  return formatCurrency(value as number);
                }
              }
            }
          }
        }
      });

      return () => {
        chart.destroy();
      };
    }
  }, [isClient, report?.marketData?.priceHistory]);

  const handleDownloadPDF = async () => {
    try {
      const response = await apiRequest('GET', `/api/reports/${report.id}/pdf`, undefined);
      
      // Convert the response to a blob
      const blob = await response.blob();
      
      // Create a URL for the blob
      const url = window.URL.createObjectURL(blob);
      
      // Create a temporary anchor element
      const a = document.createElement('a');
      a.href = url;
      a.download = `crypto-analysis-report-${report.id}.pdf`;
      document.body.appendChild(a);
      a.click();
      
      // Clean up
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Download Started",
        description: "Your report PDF is downloading.",
      });
    } catch (error) {
      console.error('Error downloading PDF:', error);
      toast({
        title: "Download Failed",
        description: "There was an error downloading your report. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!report) return null;

  return (
    <Card className="mb-10">
      <CardHeader className="p-6 border-b border-border flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Your Portfolio Analysis</h2>
          <p className="text-muted-foreground mt-1">Generated on {report.generatedAt}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Share2 className="mr-2 h-4 w-4" /> Share
          </Button>
          <Button size="sm" onClick={handleDownloadPDF}>
            <Download className="mr-2 h-4 w-4" /> Download PDF
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="space-y-8">
          {/* Portfolio Overview */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Portfolio Overview</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="bg-muted/30 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-sm font-medium">Value Distribution</h4>
                    <span className="text-xs text-muted-foreground">
                      Total: {formatCurrency(report.portfolio.totalValue)}
                    </span>
                  </div>
                  <div className="h-64 relative">
                    <canvas ref={portfolioChartRef}></canvas>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="bg-muted/30 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-sm font-medium">Performance Summary</h4>
                    <span className={`text-xs ${report.portfolio.overallPerformance >= 0 ? 'text-secondary' : 'text-destructive'}`}>
                      {formatPercentage(report.portfolio.overallPerformance)} Overall
                    </span>
                  </div>
                  <div className="space-y-3">
                    {report.portfolio.coinPerformance.map((coin: any, index: number) => (
                      <div key={index}>
                        <div className="flex justify-between text-sm mb-1">
                          <span>{coin.name} ({coin.symbol})</span>
                          <span className={coin.performance >= 0 ? 'text-secondary' : 'text-destructive'}>
                            {formatPercentage(coin.performance)}
                          </span>
                        </div>
                        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                          <div 
                            className={`${coin.performance >= 0 ? 'bg-secondary' : 'bg-destructive'} h-full rounded-full`} 
                            style={{width: `${Math.abs(coin.performance) * 2}%`}}
                          ></div>
                        </div>
                      </div>
                    ))}
                    
                    <div className="mt-4 pt-4 border-t border-border">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-muted rounded-md p-3 text-center">
                          <p className="text-xs text-muted-foreground mb-1">Risk Score</p>
                          <p className="text-xl font-mono font-medium">{report.portfolio.riskScore}/10</p>
                          <p className="text-xs text-amber-500">{report.portfolio.riskLevel}</p>
                        </div>
                        
                        <div className="bg-muted rounded-md p-3 text-center">
                          <p className="text-xs text-muted-foreground mb-1">Diversification</p>
                          <p className="text-xl font-mono font-medium">{report.portfolio.diversificationScore}/10</p>
                          <p className="text-xs text-amber-500">{report.portfolio.diversificationStatus}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Market Insights */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Market Insights</h3>
            
            <div className="bg-muted/30 rounded-lg p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {report.marketInsights.map((insight: any, index: number) => (
                  <div key={index} className="bg-muted rounded-md p-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <h4 className="text-sm font-medium">{insight.title}</h4>
                      <div className={`h-8 w-8 rounded-full ${insight.sentiment === 'bullish' ? 'bg-secondary' : 'bg-destructive'} flex items-center justify-center`}>
                        {insight.sentiment === 'bullish' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">{insight.description}</p>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 pt-4 border-t border-border">
                <h4 className="text-sm font-medium mb-2">Bitcoin Price Trend (Last 30 Days)</h4>
                <div className="h-64 relative">
                  <canvas ref={priceChartRef}></canvas>
                </div>
              </div>
            </div>
          </div>
          
          {/* Recommendations */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Recommendations</h3>
            
            <div className="bg-muted/30 rounded-lg p-4 space-y-4">
              {report.recommendations.map((recommendation: any, index: number) => {
                const icons = {
                  "portfolio": <Lightbulb className="h-4 w-4" />,
                  "strategy": <BarChart className="h-4 w-4" />,
                  "risk": <ShieldCheck className="h-4 w-4" />
                };
                const colors = {
                  "portfolio": "bg-primary",
                  "strategy": "bg-secondary",
                  "risk": "bg-accent"
                };
                return (
                  <div key={index} className="flex items-start gap-3">
                    <div className={`flex-shrink-0 h-8 w-8 rounded-full ${colors[recommendation.type as keyof typeof colors]} flex items-center justify-center`}>
                      {icons[recommendation.type as keyof typeof icons]}
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">{recommendation.title}</h4>
                      <p className="text-xs text-muted-foreground mt-1">{recommendation.description}</p>
                    </div>
                  </div>
                );
              })}
              
              {report.opportunities && (
                <div className="pt-4 border-t border-border">
                  <h4 className="text-sm font-medium mb-3">Investment Opportunities</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {report.opportunities.map((opportunity: any, index: number) => (
                      <div key={index} className="bg-muted rounded-md p-3 flex items-center gap-3">
                        <div className="h-10 w-10 bg-background rounded-full flex items-center justify-center">
                          <div className="text-xl font-bold">{opportunity.symbol.slice(0, 1)}</div>
                        </div>
                        <div>
                          <h5 className="text-sm font-medium">{opportunity.name} ({opportunity.symbol})</h5>
                          <p className="text-xs text-secondary mt-0.5">{opportunity.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
