import { Link } from "wouter";
import { Bot, PieChart, ShieldCheck, Coins, Brain, Lightbulb } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function FeatureHighlights() {
  return (
    <section className="mb-10">
      <div className="flex flex-col items-center text-center mb-8">
        <h2 className="text-2xl font-semibold mb-2">Why Crypto Investors Choose Us</h2>
        <p className="text-muted-foreground max-w-2xl">
          In a market filled with volatility and uncertainty, our analysis gives you the clarity 
          to make informed decisions and reduce the stress of crypto investing.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="flex flex-col">
          <CardContent className="p-6 flex-1 flex flex-col">
            <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-4">
              <Brain className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-medium mb-2">End Investment Confusion</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Cut through the noise with AI-powered insights that translate complex market data into clear, actionable intelligence.
            </p>
            <div className="mt-auto">
              <Link href="/analysis" className="text-sm text-primary inline-flex items-center">
                Start analysis <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        <Card className="flex flex-col">
          <CardContent className="p-6 flex-1 flex flex-col">
            <div className="h-12 w-12 rounded-lg bg-secondary/10 flex items-center justify-center text-secondary mb-4">
              <Coins className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-medium mb-2">Affordable Expert Insights</h3>
            <p className="text-muted-foreground text-sm mb-4">
              For just the price of a cup of coffee (10 USDT), unlock professional-grade analysis that could save you thousands in potential losses.
            </p>
            <div className="mt-auto">
              <Link href="/report/sample" className="text-sm text-primary inline-flex items-center">
                View sample report <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        <Card className="flex flex-col">
          <CardContent className="p-6 flex-1 flex flex-col">
            <div className="h-12 w-12 rounded-lg bg-accent/10 flex items-center justify-center text-accent mb-4">
              <Lightbulb className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-medium mb-2">Reduce Investment Stress</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Sleep better knowing your portfolio has been professionally analyzed with tailored risk management strategies aligned to your goals.
            </p>
            <div className="mt-auto">
              <Link href="/analysis" className="text-sm text-primary inline-flex items-center">
                Get started <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 p-6 bg-muted/30 rounded-lg border border-border">
        <h3 className="text-lg font-medium mb-3">How It Works</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="flex gap-3 items-start">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">1</div>
            <div>
              <p className="font-medium text-sm">Upload your crypto holdings</p>
              <p className="text-xs text-muted-foreground">Enter coin details or upload files/screenshots</p>
            </div>
          </div>
          
          <div className="flex gap-3 items-start">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">2</div>
            <div>
              <p className="font-medium text-sm">Get free portfolio score</p>
              <p className="text-xs text-muted-foreground">See an overview of your risk and diversification</p>
            </div>
          </div>
          
          <div className="flex gap-3 items-start">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">3</div>
            <div>
              <p className="font-medium text-sm">Unlock full report (10 USDT)</p>
              <p className="text-xs text-muted-foreground">Pay via TRC20 - less than a cup of coffee</p>
            </div>
          </div>
          
          <div className="flex gap-3 items-start">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">4</div>
            <div>
              <p className="font-medium text-sm">Optimize your investments</p>
              <p className="text-xs text-muted-foreground">Apply expert insights to your strategy</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
