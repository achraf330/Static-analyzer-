import { useState, useRef } from "react";
import { useDropzone } from "react-dropzone";
import { FileUpIcon, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface FileUploadProps {
  files: File[];
  setFiles: React.Dispatch<React.SetStateAction<File[]>>;
}

export default function FileUpload({ files, setFiles }: FileUploadProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const onDrop = (acceptedFiles: File[]) => {
    // Check file size
    const validFiles = acceptedFiles.filter(file => file.size <= 10 * 1024 * 1024); // 10MB limit
    
    if (validFiles.length !== acceptedFiles.length) {
      toast({
        title: "File too large",
        description: "Some files exceed the 10MB limit and were not added.",
        variant: "destructive",
      });
    }
    
    setFiles(prev => [...prev, ...validFiles]);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'image/png': ['.png'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'application/pdf': ['.pdf'],
      'text/csv': ['.csv'],
      'text/plain': ['.txt']
    },
    maxSize: 10 * 1024 * 1024 // 10MB
  });

  const handleRemoveFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="bg-muted/30 rounded-md p-4">
      <div 
        {...getRootProps()} 
        className={`border-2 border-dashed border-input rounded-md p-6 flex flex-col items-center justify-center text-center cursor-pointer ${
          isDragActive ? 'border-primary' : ''
        }`}
      >
        <div className="mb-4 text-accent">
          <FileUpIcon className="h-10 w-10" />
        </div>
        <h4 className="text-sm font-medium mb-1">Upload a file or screenshot</h4>
        <p className="text-xs text-muted-foreground mb-4">Drag and drop, or click to select files</p>
        <input {...getInputProps()} ref={fileInputRef} />
        <Button 
          type="button" 
          variant="outline" 
          onClick={(e) => {
            e.stopPropagation();
            fileInputRef.current?.click();
          }}
        >
          Select Files
        </Button>
        <p className="text-xs text-muted-foreground mt-3">Supported formats: PNG, JPG, PDF, CSV, TXT (Max 10MB)</p>
      </div>
      
      {files.length > 0 && (
        <div className="mt-4">
          <h4 className="text-sm font-medium mb-2">Uploaded Files</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {files.map((file, index) => (
              <div key={index} className="flex items-center gap-3 p-3 bg-muted rounded-md">
                <div className="flex-shrink-0 h-10 w-10 bg-background rounded flex items-center justify-center">
                  <FileUpIcon className="h-5 w-5 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm truncate">{file.name}</p>
                  <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
                </div>
                <button 
                  className="flex-shrink-0 text-muted-foreground hover:text-destructive transition-colors"
                  onClick={() => handleRemoveFile(index)}
                  type="button"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
