import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function HeroSection() {
  return (
    <section className="mb-10 mt-4">
      <Card className="border shadow-sm">
        <CardContent className="p-6 md:p-8">
          <div className="grid gap-6 md:grid-cols-2 md:gap-12 items-center">
            <div>
              <h1 className="text-3xl font-bold mb-3">End Crypto Investment Stress</h1>
              <p className="text-muted-foreground mb-3">
                In the chaotic world of cryptocurrencies, confusion and stress are holding investors back. Our AI-powered analysis cuts through the noise to provide clarity and confidence.
              </p>
              <p className="text-muted-foreground mb-6">
                Get a professional portfolio review for <span className="font-medium text-primary">just the price of a cup of coffee</span> - unlock detailed insights, risk assessment, and personalized recommendations to optimize your crypto investments.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Link href="/analysis">
                  <Button>Start New Analysis</Button>
                </Link>
                <Link href="/report/sample">
                  <Button variant="outline">View Sample Report</Button>
                </Link>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <img 
                src="https://images.unsplash.com/photo-1640340434855-6084b1f4901c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                alt="Cryptocurrency analysis" 
                className="rounded-lg border shadow-md w-full max-w-md"
                width="500"
                height="300"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
