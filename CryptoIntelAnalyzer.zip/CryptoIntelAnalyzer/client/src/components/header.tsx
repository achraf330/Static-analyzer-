import { Link } from "wouter";
import { useLocation } from "wouter";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { ChartLine, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetTrigger, SheetContent } from "@/components/ui/sheet";
import { useMobile } from "@/hooks/use-mobile";

export default function Header() {
  const [location] = useLocation();
  const isMobile = useMobile();

  const navItems = [
    { name: "Home", path: "/" },
    { name: "Dashboard", path: "/analysis" },
    { name: "Reports", path: "/report" },
    { name: "FAQ", path: "/faq" },
    { name: "Support", path: "/support" }
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <ChartLine className="h-5 w-5 text-primary" />
          <Link href="/" className="text-xl font-semibold bg-gradient-to-r from-indigo-500 to-purple-600 bg-clip-text text-transparent">
            OnPoint
          </Link>
        </div>
        
        <nav className="hidden md:flex gap-6">
          {navItems.map((item) => (
            <Link 
              key={item.path} 
              href={item.path}
              className={`text-sm font-medium hover:text-primary transition-colors ${
                location === item.path ? "text-primary" : ""
              }`}
            >
              {item.name}
            </Link>
          ))}
        </nav>
        
        <div className="flex items-center gap-4">
          <ThemeToggle />
          
          {isMobile && (
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <nav className="flex flex-col gap-4 mt-8">
                  {navItems.map((item) => (
                    <Link 
                      key={item.path} 
                      href={item.path}
                      className={`text-sm font-medium hover:text-primary transition-colors p-2 ${
                        location === item.path ? "text-primary bg-muted rounded-md" : ""
                      }`}
                    >
                      {item.name}
                    </Link>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          )}
        </div>
      </div>
    </header>
  );
}
