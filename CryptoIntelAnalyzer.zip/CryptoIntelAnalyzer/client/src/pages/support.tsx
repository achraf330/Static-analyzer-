import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Send, User, MailQuestion, Clock, Check, AlertCircle } from "lucide-react";

// Message type for chat
interface Message {
  id: string;
  content: string;
  sender: 'user' | 'support';
  timestamp: Date;
}

// Chat session type
interface ChatSession {
  id: string;
  messages: Message[];
  lastMessage: string;
  lastActivity: Date;
  status: 'active' | 'waiting' | 'resolved';
  unread: number;
}

// Quick answers that support can use
const quickAnswers = [
  {
    title: "Payment Issues",
    answers: [
      "To verify your payment, please enter the transaction ID (TXID) in the verification field on the payment page.",
      "Our system requires exact payment amounts including the decimal portion (e.g., 10.0003 USDT) to properly link transactions to reports.",
      "Payments must be made on the TRC20 network to be correctly processed by our system."
    ]
  },
  {
    title: "Technical Questions",
    answers: [
      "Your portfolio score is calculated based on multiple factors including diversification, volatility, and performance metrics.",
      "You can upload your portfolio data either manually or by uploading a screenshot/image of your holdings.",
      "For optimal analysis, please provide accurate purchase prices and dates if available."
    ]
  },
  {
    title: "Account Support",
    answers: [
      "You can re-analyze your portfolio at any time by starting a new analysis session.",
      "All your previous reports are accessible through your account dashboard.",
      "We don't store your wallet addresses or private keys, only the portfolio composition data you provide."
    ]
  }
];

export default function Support() {
  const [message, setMessage] = useState('');
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [hasStartedChat, setHasStartedChat] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [issue, setIssue] = useState('');
  const messageEndRef = useRef<HTMLDivElement>(null);
  
  // Demo chats for the support interface
  const [chats, setChats] = useState<ChatSession[]>([
    {
      id: 'chat1',
      messages: [
        {
          id: '1',
          content: "Hi, I'm having trouble verifying my payment. I sent the USDT but the system isn't recognizing my transaction.",
          sender: 'user',
          timestamp: new Date(Date.now() - 35 * 60000)
        },
        {
          id: '2',
          content: "Hello! I'd be happy to help with your payment verification. Could you please provide your transaction ID (TXID) so I can check what might be happening?",
          sender: 'support',
          timestamp: new Date(Date.now() - 32 * 60000)
        },
        {
          id: '3',
          content: "Sure, it's TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE",
          sender: 'user',
          timestamp: new Date(Date.now() - 30 * 60000)
        }
      ],
      lastMessage: "Sure, it's TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE",
      lastActivity: new Date(Date.now() - 30 * 60000),
      status: 'active',
      unread: 0
    },
    {
      id: 'chat2',
      messages: [
        {
          id: '1',
          content: "Hello, I'm wondering how often I should update my portfolio analysis?",
          sender: 'user',
          timestamp: new Date(Date.now() - 120 * 60000)
        }
      ],
      lastMessage: "Hello, I'm wondering how often I should update my portfolio analysis?",
      lastActivity: new Date(Date.now() - 120 * 60000),
      status: 'waiting',
      unread: 1
    }
  ]);

  // Simulated user chat session
  const [userChat, setUserChat] = useState<Message[]>([
    {
      id: 'system-1',
      content: "Hello! Welcome to OnPoint support. How can we help you today?",
      sender: 'support',
      timestamp: new Date()
    }
  ]);

  // Auto-scroll to the latest message
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [userChat, activeChat, chats]);

  // Handle sending a message (for both support view and user view)
  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    const newMessage: Message = {
      id: Date.now().toString(),
      content: message,
      sender: 'user',
      timestamp: new Date()
    };
    
    if (activeChat) {
      // Support view - add message to existing chat
      setChats(prev => prev.map(chat => 
        chat.id === activeChat 
          ? {
              ...chat,
              messages: [...chat.messages, newMessage],
              lastMessage: message,
              lastActivity: new Date()
            }
          : chat
      ));
    } else {
      // User view - add message to user chat
      setUserChat(prev => [...prev, newMessage]);
      
      // Simulate support response after a delay
      setTimeout(() => {
        const responseMessage: Message = {
          id: `support-${Date.now()}`,
          content: "Thank you for your message. Our support team will respond shortly. In the meantime, you might find answers to common questions in our FAQ section.",
          sender: 'support',
          timestamp: new Date()
        };
        setUserChat(prev => [...prev, responseMessage]);
      }, 1000);
    }
    
    setMessage('');
  };

  // Handle starting a new chat (from user's perspective)
  const handleStartChat = () => {
    if (!name.trim() || !email.trim() || !issue.trim()) return;
    
    const initialMessage: Message = {
      id: Date.now().toString(),
      content: issue,
      sender: 'user',
      timestamp: new Date()
    };
    
    setUserChat([
      {
        id: 'system-1',
        content: "Hello! Welcome to OnPoint support. How can we help you today?",
        sender: 'support',
        timestamp: new Date()
      },
      initialMessage
    ]);
    
    setHasStartedChat(true);
    setName('');
    setEmail('');
    setIssue('');
    
    // Simulate support response after a delay
    setTimeout(() => {
      const responseMessage: Message = {
        id: `support-${Date.now()}`,
        content: "Thank you for your message. Our support team will respond shortly. In the meantime, you might find answers to common questions in our FAQ section.",
        sender: 'support',
        timestamp: new Date()
      };
      setUserChat(prev => [...prev, responseMessage]);
    }, 1000);
  };

  // Insert a quick answer into the message input (support view)
  const insertQuickAnswer = (answer: string) => {
    setMessage(answer);
  };

  // Format timestamp for display
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Get status badge for chat sessions
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="secondary" className="ml-2 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">Active</Badge>;
      case 'waiting':
        return <Badge variant="secondary" className="ml-2 bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">Waiting</Badge>;
      case 'resolved':
        return <Badge variant="secondary" className="ml-2 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">Resolved</Badge>;
      default:
        return null;
    }
  };

  // Render the Support Dashboard (admin view)
  const renderSupportDashboard = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 border-r pr-4">
          <div className="mb-4">
            <h3 className="text-lg font-medium">Active Conversations</h3>
            <p className="text-sm text-muted-foreground">Manage user support requests</p>
          </div>
          
          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {chats.map(chat => (
              <Card 
                key={chat.id} 
                className={`cursor-pointer hover:bg-muted/50 transition-colors ${activeChat === chat.id ? 'border-primary' : ''}`}
                onClick={() => setActiveChat(chat.id)}
              >
                <CardContent className="p-3">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      <User className="h-5 w-5 text-muted-foreground mr-2" />
                      <div>
                        <p className="font-medium">User {chat.id.replace('chat', '')}</p>
                        <p className="text-xs text-muted-foreground">
                          {chat.lastMessage.length > 25 
                            ? chat.lastMessage.substring(0, 25) + '...' 
                            : chat.lastMessage}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-xs text-muted-foreground">
                        {formatTime(chat.lastActivity)}
                      </span>
                      {chat.unread > 0 && (
                        <Badge variant="destructive" className="mt-1">{chat.unread}</Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-xs flex items-center text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      {Math.floor((Date.now() - chat.lastActivity.getTime()) / 60000)} min ago
                    </span>
                    {getStatusBadge(chat.status)}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        
        <div className="md:col-span-2">
          {activeChat ? (
            <Card className="h-full flex flex-col">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-lg">Conversation with User {activeChat.replace('chat', '')}</CardTitle>
                    <CardDescription>Support ticket #{activeChat.replace('chat', '1000')}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => setActiveChat(null)}>
                      Back
                    </Button>
                    <Button variant="outline" size="sm" className="text-green-600 border-green-600">
                      <Check className="h-4 w-4 mr-1" />
                      Mark Resolved
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-grow overflow-hidden">
                <div className="h-[400px] overflow-y-auto mb-4 pr-2">
                  {chats.find(c => c.id === activeChat)?.messages.map((msg, i) => (
                    <div 
                      key={msg.id} 
                      className={`mb-4 ${msg.sender === 'user' ? 'text-right' : ''}`}
                    >
                      <div 
                        className={`inline-block max-w-[80%] px-4 py-2 rounded-lg ${
                          msg.sender === 'user' 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-muted'
                        }`}
                      >
                        {msg.content}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {formatTime(msg.timestamp)}
                      </div>
                    </div>
                  ))}
                  <div ref={messageEndRef} />
                </div>
                
                <div className="flex gap-2">
                  <Input
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type your response..."
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button onClick={handleSendMessage} disabled={!message.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col items-start pt-0">
                <Tabs defaultValue="payment" className="w-full mt-4">
                  <TabsList className="w-full">
                    {quickAnswers.map((category, i) => (
                      <TabsTrigger key={i} value={category.title.toLowerCase().replace(' ', '-')}>
                        {category.title}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  {quickAnswers.map((category, i) => (
                    <TabsContent key={i} value={category.title.toLowerCase().replace(' ', '-')} className="mt-2">
                      <div className="space-y-2">
                        {category.answers.map((answer, j) => (
                          <div key={j} className="border rounded p-2 text-sm hover:bg-muted cursor-pointer" onClick={() => insertQuickAnswer(answer)}>
                            {answer.length > 80 ? answer.substring(0, 80) + '...' : answer}
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                  ))}
                </Tabs>
              </CardFooter>
            </Card>
          ) : (
            <div className="h-full flex items-center justify-center border rounded-lg bg-muted/50">
              <div className="text-center max-w-md p-6">
                <MailQuestion className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No conversation selected</h3>
                <p className="text-muted-foreground">
                  Select a conversation from the list to view and respond to support requests.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  // Render User Chat Interface
  const renderUserChatInterface = () => {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Customer Support</CardTitle>
          <CardDescription>
            Chat with our support team to get help with your queries
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!hasStartedChat ? (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Name</label>
                <Input 
                  placeholder="Your name" 
                  value={name} 
                  onChange={(e) => setName(e.target.value)} 
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Email</label>
                <Input 
                  placeholder="Your email" 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">How can we help you?</label>
                <Input 
                  placeholder="Describe your issue..." 
                  value={issue} 
                  onChange={(e) => setIssue(e.target.value)} 
                />
              </div>
              <Button onClick={handleStartChat} disabled={!name.trim() || !email.trim() || !issue.trim()}>
                Start Chat
              </Button>
              <div className="mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <AlertCircle className="h-4 w-4" />
                <p>You can also check our <a href="/faq" className="text-primary">FAQ page</a> for quick answers</p>
              </div>
            </div>
          ) : (
            <div>
              <div className="h-[400px] overflow-y-auto mb-4 p-2 border rounded-lg">
                {userChat.map((msg, i) => (
                  <div 
                    key={i} 
                    className={`mb-4 ${msg.sender === 'user' ? 'text-right' : ''}`}
                  >
                    <div 
                      className={`inline-block max-w-[80%] px-4 py-2 rounded-lg ${
                        msg.sender === 'user' 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-muted'
                      }`}
                    >
                      {msg.content}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {formatTime(msg.timestamp)}
                    </div>
                  </div>
                ))}
                <div ref={messageEndRef} />
              </div>
              
              <div className="flex gap-2">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message..."
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                />
                <Button onClick={handleSendMessage} disabled={!message.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="container py-8">
      <div className="max-w-6xl mx-auto">
        <Tabs defaultValue="user">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">Support Center</h1>
              <p className="text-muted-foreground">Get help with your OnPoint crypto portfolio analysis</p>
            </div>
            <TabsList>
              <TabsTrigger value="user">User View</TabsTrigger>
              <TabsTrigger value="support">Support Dashboard (Demo)</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="user" className="mt-0">
            {renderUserChatInterface()}
          </TabsContent>
          
          <TabsContent value="support" className="mt-0">
            {renderSupportDashboard()}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}