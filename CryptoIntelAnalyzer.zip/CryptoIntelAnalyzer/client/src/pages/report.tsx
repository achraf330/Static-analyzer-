import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { useToast } from "@/hooks/use-toast";
import ReportPreview from "@/components/report-preview";
import PortfolioScore from "@/components/portfolio-score";
import PaymentSection from "@/components/payment-section";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Report() {
  const { id } = useParams();
  const { toast } = useToast();
  const [paymentStatus, setPaymentStatus] = useState('checking');

  // Get the report data
  const { data: report, isLoading: reportLoading, error: reportError } = useQuery({
    queryKey: [`/api/reports/${id}`],
    staleTime: Infinity,
  });

  // Get the payment status
  const { data: paymentData, isLoading: paymentLoading, refetch: refetchPayment } = useQuery({
    queryKey: [`/api/payment/status/${id}`],
    enabled: !!id && id !== 'sample',
    staleTime: 0, // Always refetch to get the latest status
  });

  useEffect(() => {
    if (paymentData) {
      setPaymentStatus(paymentData.status);
    }
  }, [paymentData]);

  useEffect(() => {
    if (reportError) {
      toast({
        title: "Error Loading Report",
        description: "Could not load the analysis report. Please try again.",
        variant: "destructive",
      });
    }
  }, [reportError, toast]);

  const handlePaymentVerified = () => {
    // Refetch the payment status to update UI
    refetchPayment();
    // Show success toast
    toast({
      title: "Payment Verified",
      description: "Your payment has been verified. You now have access to the full report.",
    });
  };

  if (reportLoading || paymentLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between">
          <div>
            <Skeleton className="h-8 w-[250px] mb-2" />
            <Skeleton className="h-4 w-[180px]" />
          </div>
          <div className="flex gap-2">
            <Skeleton className="h-9 w-[80px]" />
            <Skeleton className="h-9 w-[120px]" />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Skeleton className="h-[300px] w-full" />
          <Skeleton className="h-[300px] w-full" />
        </div>
        
        <Skeleton className="h-[200px] w-full" />
        <Skeleton className="h-[300px] w-full" />
      </div>
    );
  }

  if (reportError || !report) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Failed to load the analysis report. Please try again later or create a new analysis.
        </AlertDescription>
      </Alert>
    );
  }

  // Special case for sample report - show full report
  if (id === 'sample') {
    return <ReportPreview report={report} />;
  }

  // If payment is verified or it's a sample report, show the full report
  if (paymentStatus === 'verified') {
    return <ReportPreview report={report} />;
  }

  // If payment is not verified, show the portfolio score and payment section
  return (
    <div className="space-y-8">
      <PortfolioScore 
        score={report.portfolio.portfolioScore || report.portfolio.riskScore * 10} 
        riskLevel={report.portfolio.riskLevel} 
        diversificationStatus={report.portfolio.diversificationStatus}
      />
      
      <PaymentSection 
        reportId={report.id}
        paymentStatus={paymentStatus}
        onPaymentVerified={handlePaymentVerified}
      />
    </div>
  );
}
