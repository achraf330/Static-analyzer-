import { useState } from 'react';
import PortfolioScore from "@/components/portfolio-score";
import PaymentSection from "@/components/payment-section";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function PaymentDemo() {
  const { toast } = useToast();
  const [paymentStatus, setPaymentStatus] = useState('unpaid');
  
  // Mock data for the demo
  const mockScore = 75;
  const mockRiskLevel = "Moderate";
  const mockDiversificationStatus = "Adequate";
  const mockReportId = "demo-123";
  
  const handlePaymentVerified = () => {
    setPaymentStatus('verified');
    toast({
      title: "Payment Verified",
      description: "Your payment has been verified. You now have access to the full report.",
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Payment Page Demo</h1>
      <p className="text-muted-foreground mb-4">
        This is a demo of the payment page showing both the free portfolio score and the payment section.
      </p>
      <div className="mb-8">
        <Link href="/thank-you-demo">
          <Button variant="outline" size="sm">View Thank You Page Demo</Button>
        </Link>
      </div>
      
      <div className="space-y-8">
        <PortfolioScore 
          score={mockScore} 
          riskLevel={mockRiskLevel} 
          diversificationStatus={mockDiversificationStatus}
        />
        
        <PaymentSection 
          reportId={mockReportId}
          paymentStatus={paymentStatus}
          onPaymentVerified={handlePaymentVerified}
        />
      </div>
    </div>
  );
}