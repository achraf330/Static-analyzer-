import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import PortfolioForm from "@/components/portfolio-form";
import ProcessingSection from "@/components/processing-section";
import { apiRequest } from "@/lib/queryClient";

export default function Analysis() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState({
    percentage: 0,
    step: "idle", // idle, extracting, analyzing, generating
    steps: {
      extracting: { status: "idle" }, // idle, processing, complete
      analyzing: { status: "idle" },
      generating: { status: "idle" }
    }
  });
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const startAnalysis = async (formData: FormData) => {
    setIsProcessing(true);
    
    try {
      // Step 1: Data extraction
      setProgress({
        percentage: 30,
        step: "extracting",
        steps: {
          extracting: { status: "processing" },
          analyzing: { status: "idle" },
          generating: { status: "idle" }
        }
      });

      const response = await apiRequest('POST', '/api/analysis', {
        formData: Object.fromEntries(formData.entries())
      });

      const data = await response.json();
      
      // Step 2: Market analysis
      setProgress({
        percentage: 60,
        step: "analyzing",
        steps: {
          extracting: { status: "complete" },
          analyzing: { status: "processing" },
          generating: { status: "idle" }
        }
      });

      // Step 3: Report generation
      setProgress({
        percentage: 90,
        step: "generating",
        steps: {
          extracting: { status: "complete" },
          analyzing: { status: "complete" },
          generating: { status: "processing" }
        }
      });

      // Complete
      setProgress({
        percentage: 100,
        step: "complete",
        steps: {
          extracting: { status: "complete" },
          analyzing: { status: "complete" },
          generating: { status: "complete" }
        }
      });

      // Redirect to the report page
      toast({
        title: "Analysis Complete",
        description: "Your crypto portfolio analysis has been generated.",
      });

      setTimeout(() => {
        setLocation(`/report/${data.reportId}`);
      }, 1000);
    } catch (error) {
      console.error('Analysis failed:', error);
      toast({
        title: "Analysis Failed",
        description: "There was an error processing your portfolio data. Please try again.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  return (
    <div>
      {!isProcessing ? (
        <PortfolioForm onSubmit={startAnalysis} />
      ) : (
        <ProcessingSection progress={progress} />
      )}
    </div>
  );
}
