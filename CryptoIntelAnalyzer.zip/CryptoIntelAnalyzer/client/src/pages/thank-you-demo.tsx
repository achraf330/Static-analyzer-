import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { CheckCircle, Download, FileText } from 'lucide-react';
import ReportPreview from '@/components/report-preview';

export default function ThankYouDemo() {
  // Mock report data for the demo
  const mockReport = {
    id: "demo-123",
    generatedAt: "May 5, 2025",
    portfolio: {
      totalValue: 15420.75,
      distribution: [
        { coin: "Bitcoin", symbol: "BTC", percentage: 45 },
        { coin: "Ethereum", symbol: "ETH", percentage: 30 },
        { coin: "Solana", symbol: "SOL", percentage: 15 },
        { coin: "Cardano", symbol: "ADA", percentage: 10 }
      ],
      overallPerformance: 12.8,
      coinPerformance: [
        { name: "Bitcoin", symbol: "BTC", performance: 15.2 },
        { name: "Ethereum", symbol: "ETH", performance: 10.5 },
        { name: "Solana", symbol: "SOL", performance: 22.3 },
        { name: "Cardano", symbol: "ADA", performance: -3.2 }
      ],
      riskScore: 7.5,
      riskLevel: "Moderate-High",
      diversificationScore: 6.8,
      diversificationStatus: "Adequate"
    },
    marketInsights: [
      { title: "Bitcoin Dominance", sentiment: "bullish", description: "BTC dominance continues to grow, suggesting increased market confidence in the leading cryptocurrency." },
      { title: "Ethereum Updates", sentiment: "bullish", description: "Upcoming protocol upgrades likely to boost ETH performance in the short to medium term." },
      { title: "Altcoin Season", sentiment: "bearish", description: "Current market conditions suggest limited altcoin growth in the next quarter." }
    ],
    recommendations: [
      { type: "portfolio", title: "Rebalance Holdings", description: "Consider reducing BTC exposure slightly and increasing SOL position based on recent performance metrics." },
      { type: "strategy", title: "DCA Implementation", description: "Implement dollar-cost averaging for your ETH purchases to reduce volatility impact." },
      { type: "risk", title: "Diversification Improvement", description: "Add 1-2 more assets from different crypto sectors to improve overall diversification." }
    ],
    opportunities: [
      { name: "Polkadot", symbol: "DOT", status: "Potential opportunity based on technical analysis" },
      { name: "Chainlink", symbol: "LINK", status: "Consider adding to diversify into oracle networks" }
    ]
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Thank You Page Demo</h1>
      <p className="text-muted-foreground mb-8">
        This is a demo of the thank you page that appears after payment verification is complete.
      </p>
      
      <Card className="mb-8 border-2 border-green-500/50 bg-green-50 dark:bg-green-900/10">
        <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/40 dark:to-emerald-950/40">
          <CardTitle className="text-xl font-bold text-green-700 dark:text-green-400 flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Investment in Clarity Confirmed!
          </CardTitle>
          <CardDescription>
            Thank you for taking this important step toward reducing confusion and stress in your crypto journey. Your full portfolio analysis is now available.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <p className="text-sm text-green-700/80 dark:text-green-400/80">
            We've unlocked detailed insights that will transform how you approach your crypto investments. Scroll down to see your complete report and downloadable PDF.
          </p>
          
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <Button className="gap-2">
              <Download className="h-4 w-4" />
              Download Full Report PDF
            </Button>
            <Link href="/payment-demo">
              <Button variant="outline" className="gap-2">
                <FileText className="h-4 w-4" />
                View Demo Payment Page
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
      
      <ReportPreview report={mockReport} />
    </div>
  );
}