import React from 'react';
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from "@/components/ui/accordion";

export default function FAQ() {
  const faqs = [
    {
      question: "What is OnPoint Crypto Portfolio Analysis?",
      answer: "OnPoint is a powerful AI-driven cryptocurrency portfolio analyzer that provides detailed insights, risk assessment, and personalized recommendations for your crypto investments. Our service analyzes your holdings and delivers actionable intelligence to help you make more informed investment decisions."
    },
    {
      question: "How does the analysis work?",
      answer: "Our platform uses a combination of live cryptocurrency market data and advanced AI models to evaluate your portfolio. We examine factors like asset distribution, risk exposure, historical performance, and market trends to provide a comprehensive analysis tailored to your specific holdings."
    },
    {
      question: "Is my portfolio information secure?",
      answer: "Absolutely. We prioritize your privacy and security. We never store your actual wallet addresses or private keys. Your portfolio data is encrypted during transmission and analysis, and we use it solely to generate your personalized report. You can also use our service without creating an account."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We currently accept USDT payments on the TRC20 network. This approach ensures maximum privacy and security for our users while keeping transaction fees minimal. Each payment has a unique identifier (the tiny decimals in the amount) to securely link it to your specific report."
    },
    {
      question: "How accurate is the portfolio score?",
      answer: "Our portfolio score is calculated using multiple factors including diversification, risk-weighted performance, volatility metrics, and correlation analysis. While no score can predict future performance with certainty, our methodology provides a reliable assessment of your portfolio's current health and potential vulnerabilities."
    },
    {
      question: "Can I analyze multiple portfolios?",
      answer: "Yes, you can analyze as many different portfolios as you'd like. Each portfolio analysis is treated as a separate report with its own unique insights and recommendations tailored to those specific holdings."
    },
    {
      question: "How often should I re-analyze my portfolio?",
      answer: "We recommend re-analyzing your portfolio after significant market movements, when making substantial changes to your holdings, or on a regular schedule (monthly/quarterly) to stay informed about your investment's health. The cryptocurrency market is highly dynamic, and regular analysis helps you stay ahead of emerging trends and risks."
    },
    {
      question: "What happens after I verify my payment?",
      answer: "Once your payment is verified, you'll gain immediate access to your full detailed report. This includes a downloadable PDF version that you can save for future reference. Your report contains personalized insights, specific recommendations, and detailed metrics about your portfolio."
    },
    {
      question: "Is this financial advice?",
      answer: "No. OnPoint provides analysis and information to help you make more informed decisions, but it does not constitute financial advice. All investment decisions should be made based on your own research and risk tolerance, possibly in consultation with a qualified financial advisor."
    },
    {
      question: "How do I contact support if I need help?",
      answer: "You can reach our support team through our dedicated Support page where we offer live chat assistance. We typically respond within a few hours, and we're committed to resolving any issues you might encounter."
    }
  ];

  return (
    <div className="container max-w-4xl py-12">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold tracking-tight mb-2">Frequently Asked Questions</h1>
        <p className="text-muted-foreground">
          Find answers to common questions about OnPoint crypto portfolio analysis
        </p>
      </div>

      <Accordion type="single" collapsible className="space-y-4">
        {faqs.map((faq, index) => (
          <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg p-1">
            <AccordionTrigger className="text-left font-medium px-4 py-2 hover:no-underline data-[state=open]:text-primary">
              {faq.question}
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4 pt-1">
              <p className="text-muted-foreground">{faq.answer}</p>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>

      <div className="mt-12 text-center border-t pt-8">
        <h2 className="text-xl font-semibold mb-4">Still have questions?</h2>
        <p className="mb-6 text-muted-foreground">
          If you couldn't find the answer you were looking for, our support team is here to help.
        </p>
        <a 
          href="/support" 
          className="inline-flex items-center px-4 py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90"
        >
          Contact Support
        </a>
      </div>
    </div>
  );
}