import { Link } from "wouter";
import HeroSection from "@/components/hero-section";
import FeatureHighlights from "@/components/feature-highlights";

export default function Home() {
  return (
    <>
      <HeroSection />
      <FeatureHighlights />
    </>
  );
}
