import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";

export default function Legal() {
  return (
    <div className="container max-w-4xl py-12">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight mb-2">Legal Information</h1>
        <p className="text-muted-foreground">
          Important legal information about our service
        </p>
      </div>

      <Tabs defaultValue="terms" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="terms">Terms of Service</TabsTrigger>
          <TabsTrigger value="privacy">Privacy Policy</TabsTrigger>
        </TabsList>
        
        <TabsContent value="terms" className="mt-0">
          <div className="prose prose-indigo dark:prose-invert max-w-none">
            <h2>Terms of Service</h2>
            <p>Last updated: May 2024</p>
            
            <h3>1. Agreement to Terms</h3>
            <p>
              By accessing or using OnPoint's cryptocurrency portfolio analysis services, you agree to be bound by these Terms of Service ("Terms"). If you disagree with any part of the terms, you may not access the service.
            </p>
            
            <h3>2. Description of Service</h3>
            <p>
              OnPoint provides cryptocurrency portfolio analysis and insights through an online platform. Our services include portfolio scoring, risk assessment, diversification analysis, and customized recommendations ("Services"). We reserve the right to modify, suspend, or discontinue any aspect of the Services at any time.
            </p>
            
            <h3>3. User Responsibilities</h3>
            <p>
              You are responsible for providing accurate information about your cryptocurrency holdings for analysis. You understand that our analysis is based on the information you provide and market data available at the time of analysis.
            </p>
            <p>
              You agree not to:
            </p>
            <ul>
              <li>Use the Services for any illegal purpose</li>
              <li>Attempt to bypass or defeat any security measures</li>
              <li>Interfere with or disrupt the Services</li>
              <li>Resell, distribute, or reproduce reports without permission</li>
            </ul>
            
            <h3>4. Payment Terms</h3>
            <p>
              Access to premium reports requires payment. All payments are processed in cryptocurrency (USDT) on the TRC20 network. Payment amounts include specific decimal values that serve as unique identifiers linking transactions to specific reports.
            </p>
            <p>
              All sales are final. We do not offer refunds once a report has been generated and delivered, except in cases where the service has failed to deliver the promised analysis.
            </p>
            
            <h3>5. Intellectual Property</h3>
            <p>
              All content, features, and functionality of the Services, including but not limited to text, graphics, logos, and software, are the exclusive property of OnPoint and are protected by copyright, trademark, and other intellectual property laws.
            </p>
            
            <h3>6. Disclaimer of Warranties</h3>
            <p>
              THE SERVICES ARE PROVIDED "AS IS" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED. We do not guarantee the accuracy, completeness, or reliability of any analysis, recommendation, or information provided through the Services.
            </p>
            
            <h3>7. Limitation of Liability</h3>
            <p>
              IN NO EVENT SHALL ONPOINT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS OR REVENUES, WHETHER INCURRED DIRECTLY OR INDIRECTLY, ARISING FROM YOUR USE OF OR INABILITY TO USE THE SERVICES.
            </p>
            
            <h3>8. Not Financial Advice</h3>
            <p>
              Information provided through our Services is for informational purposes only and does not constitute financial, investment, or trading advice. We are not registered financial advisors. All investment decisions should be made at your own discretion and risk.
            </p>
            
            <h3>9. Governing Law</h3>
            <p>
              These Terms shall be governed by and construed in accordance with the laws of [Your Jurisdiction], without regard to its conflict of law provisions.
            </p>
            
            <h3>10. Changes to Terms</h3>
            <p>
              We reserve the right to modify these Terms at any time. We will provide notice of significant changes by updating the date at the top of these Terms. Your continued use of the Services after such modifications constitutes your acceptance of the revised Terms.
            </p>
            
            <h3>11. Contact Us</h3>
            <p>
              If you have any questions about these Terms, please contact us at support@onpoint-crypto.com.
            </p>
          </div>
        </TabsContent>
        
        <TabsContent value="privacy" className="mt-0">
          <div className="prose prose-indigo dark:prose-invert max-w-none">
            <h2>Privacy Policy</h2>
            <p>Last updated: May 2024</p>
            
            <h3>1. Information We Collect</h3>
            <p>
              We collect information that you voluntarily provide to us when using our Services, including:
            </p>
            <ul>
              <li>Portfolio data (coin types, amounts, purchase prices)</li>
              <li>Transaction IDs for payment verification</li>
              <li>Optional contact information if you reach out to our support team</li>
            </ul>
            <p>
              We do not collect or store your wallet addresses, private keys, or other sensitive authentication information.
            </p>
            
            <h3>2. How We Use Your Information</h3>
            <p>
              We use the information we collect to:
            </p>
            <ul>
              <li>Generate portfolio analysis and recommendations</li>
              <li>Verify payments for premium services</li>
              <li>Improve our analytical models and services</li>
              <li>Respond to your inquiries and support requests</li>
            </ul>
            
            <h3>3. Data Security</h3>
            <p>
              We implement reasonable security measures to protect the personal information we collect and maintain. However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
            </p>
            
            <h3>4. Data Retention</h3>
            <p>
              We retain your portfolio data only for as long as necessary to provide you with the requested analysis. Transaction IDs are retained for verification purposes and to prevent fraud. You may request deletion of your data by contacting our support team.
            </p>
            
            <h3>5. Cookies and Tracking</h3>
            <p>
              We use cookies and similar tracking technologies to enhance your experience on our platform. These technologies may collect information about your browsing activities and preferences. You can configure your browser to refuse cookies, although this may limit your ability to use some features of our Services.
            </p>
            
            <h3>6. Third-Party Services</h3>
            <p>
              We may employ third-party companies and individuals to facilitate our Services, perform Service-related functions, or analyze how our Services are used. These third parties have access only to the information needed to perform their functions and are obligated to maintain the confidentiality of any personal information.
            </p>
            
            <h3>7. Your Rights</h3>
            <p>
              Depending on your location, you may have certain rights regarding your personal information, including rights to access, correct, delete, and export your data. To exercise these rights, please contact us using the information provided below.
            </p>
            
            <h3>8. Children's Privacy</h3>
            <p>
              Our Services are not directed to persons under 18. We do not knowingly collect personal information from children. If you are a parent or guardian and believe that your child has provided us with personal information, please contact us.
            </p>
            
            <h3>9. Changes to This Privacy Policy</h3>
            <p>
              We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.
            </p>
            
            <h3>10. Contact Us</h3>
            <p>
              If you have questions or concerns about this Privacy Policy, please contact us at privacy@onpoint-crypto.com.
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}