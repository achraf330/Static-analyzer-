import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

interface UseFileUploadOptions {
  maxSizeInBytes?: number;
  acceptedFormats?: string[];
  maxFiles?: number;
}

export const useFileUpload = (options: UseFileUploadOptions = {}) => {
  const {
    maxSizeInBytes = 10 * 1024 * 1024, // 10MB default
    acceptedFormats = ['image/png', 'image/jpeg', 'application/pdf', 'text/csv', 'text/plain'],
    maxFiles = 5,
  } = options;

  const [files, setFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const validateFile = (file: File): boolean => {
    // Check file size
    if (file.size > maxSizeInBytes) {
      toast({
        title: 'File too large',
        description: `${file.name} exceeds the maximum size of ${maxSizeInBytes / 1024 / 1024}MB`,
        variant: 'destructive',
      });
      return false;
    }

    // Check file format
    if (!acceptedFormats.includes(file.type)) {
      toast({
        title: 'Invalid file format',
        description: `${file.name} is not a supported file format`,
        variant: 'destructive',
      });
      return false;
    }

    return true;
  };

  const addFiles = (newFiles: FileList | File[]): void => {
    const filesArray = Array.from(newFiles);
    
    // Check number of files
    if (files.length + filesArray.length > maxFiles) {
      toast({
        title: 'Too many files',
        description: `You can only upload a maximum of ${maxFiles} files`,
        variant: 'destructive',
      });
      return;
    }

    // Validate each file
    const validFiles = filesArray.filter(validateFile);

    setFiles((prevFiles) => [...prevFiles, ...validFiles]);
  };

  const removeFile = (index: number): void => {
    setFiles((prevFiles) => prevFiles.filter((_, i) => i !== index));
  };

  const clearFiles = (): void => {
    setFiles([]);
  };

  return {
    files,
    isUploading,
    addFiles,
    removeFile,
    clearFiles,
    setIsUploading,
  };
};
