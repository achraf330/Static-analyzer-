import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    console.log("Starting database seed...");

    // Create a sample report for demo purposes
    const sampleReport = {
      id: "sample-report-123",
      clientName: "John Doe",
      clientEmail: "john.doe@example.com",
      reportData: JSON.stringify({
        id: "sample-report-123",
        generatedAt: new Date().toLocaleDateString('en-US', {
          year: 'numeric', 
          month: 'long', 
          day: 'numeric'
        }),
        portfolio: {
          totalValue: 42350,
          distribution: [
            { coin: "Bitcoin", symbol: "BTC", percentage: 45 },
            { coin: "Ethereum", symbol: "ETH", percentage: 25 },
            { coin: "Solana", symbol: "SOL", percentage: 20 },
            { coin: "Other", symbol: "OTHER", percentage: 10 }
          ],
          overallPerformance: 12.3,
          coinPerformance: [
            { name: "Bitcoin", symbol: "BTC", performance: 15.7 },
            { name: "Ethereum", symbol: "ETH", performance: 8.2 },
            { name: "Solana", symbol: "SOL", performance: -3.4 }
          ],
          riskScore: 7.2,
          riskLevel: "Moderate-High",
          diversificationScore: 5.4,
          diversificationStatus: "Needs Improvement"
        },
        marketInsights: [
          {
            title: "BTC Market Sentiment",
            sentiment: "bullish",
            description: "Current market sentiment for Bitcoin is bullish with strong institutional buying signals."
          },
          {
            title: "ETH Technical Analysis",
            sentiment: "bullish",
            description: "Ethereum is showing a bullish pattern with the recent Shanghai upgrade and increased DeFi activity."
          },
          {
            title: "SOL Market Analysis",
            sentiment: "bearish",
            description: "Solana facing short-term bearish pressure due to recent network congestion issues."
          }
        ],
        marketData: {
          priceHistory: {
            dates: Array.from({length: 30}, (_, i) => {
              const date = new Date();
              date.setDate(date.getDate() - (30 - i));
              return date.toLocaleDateString('en-US', {month: 'short', day: 'numeric'});
            }),
            prices: [
              35000, 34800, 34600, 34200, 34800, 35200, 35600, 
              35400, 35100, 34900, 35300, 36100, 36800, 37200, 
              37600, 38100, 38700, 38500, 38200, 37800, 38200, 
              38600, 39200, 39800, 40100, 39800, 39400, 39600, 
              39800, 40200
            ]
          }
        },
        recommendations: [
          {
            type: "portfolio",
            title: "Portfolio Rebalancing Opportunity",
            description: "Consider increasing your Ethereum allocation from 25% to 35% based on the upcoming network upgrades and strong fundamentals."
          },
          {
            type: "strategy",
            title: "Diversification Strategy",
            description: "Your portfolio shows high concentration risk. Consider adding exposure to Layer 2 solutions and DeFi protocols to increase diversification."
          },
          {
            type: "risk",
            title: "Risk Management",
            description: "Given your moderate risk profile, consider implementing stop-loss strategies for your Solana position to protect against further downside."
          }
        ],
        opportunities: [
          {
            name: "Polygon",
            symbol: "MATIC",
            status: "High Potential"
          },
          {
            name: "Chainlink",
            symbol: "LINK",
            status: "Recommended"
          }
        ]
      }),
      generatedAt: new Date().toISOString(),
      createdAt: new Date()
    };

    // Check if the sample report already exists to avoid duplicates
    const existingReport = await db.query.reports.findFirst({
      where: (reports, { eq }) => eq(reports.reportId, "sample-report-123")
    });

    if (!existingReport) {
      await db.insert(schema.reports).values({
        reportId: sampleReport.id,
        clientName: sampleReport.clientName,
        clientEmail: sampleReport.clientEmail,
        reportData: sampleReport.reportData,
        generatedAt: sampleReport.generatedAt
      });
      console.log("Sample report created successfully");
    } else {
      console.log("Sample report already exists, skipping...");
    }

    console.log("Database seed completed successfully");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
