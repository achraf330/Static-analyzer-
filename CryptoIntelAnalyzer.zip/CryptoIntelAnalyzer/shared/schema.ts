import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Crypto Portfolio Reports
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  reportId: text("report_id").notNull().unique(),
  clientName: text("client_name").notNull(),
  clientEmail: text("client_email").notNull(),
  reportData: text("report_data").notNull(), // JSON string of the report
  generatedAt: text("generated_at").notNull(),
  portfolioScore: integer("portfolio_score"), // Score out of 100
  paymentStatus: text("payment_status").default("unpaid").notNull(), // unpaid, pending, paid
  transactionId: text("transaction_id"), // TRC20 transaction ID
  paymentAmount: text("payment_amount").default("10").notNull(), // Amount in USDT
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertReportSchema = createInsertSchema(reports, {
  clientName: (schema) => schema.min(2, "Name must be at least 2 characters"),
  clientEmail: (schema) => schema.email("Must provide a valid email"),
  reportData: (schema) => schema.min(1, "Report data is required")
});

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;
