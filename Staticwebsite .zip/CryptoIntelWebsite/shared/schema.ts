import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Crypto Holding schema for validation
export const cryptoHoldingSchema = z.object({
  id: z.string(),
  coin: z.string().min(1, "Please select a coin"),
  quantity: z.number().min(0.000001, "Please enter a valid quantity"),
  avgBuyPrice: z.number().min(0.000001, "Please enter a valid price"),
});

// Analysis Request schema and model
export const analysisRequests = pgTable("analysis_requests", {
  id: serial("id").primaryKey(),
  name: text("name"),
  email: text("email").notNull(),
  investmentGoals: text("investment_goals").notNull(),
  riskAppetite: text("risk_appetite").notNull(),
  timeframe: text("timeframe").notNull(),
  holdings: jsonb("holdings").notNull(),
  txHash: text("tx_hash"),
  status: text("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const analysisRequestSchema = z.object({
  name: z.string().optional(),
  email: z.string().email("Please enter a valid email address"),
  investmentGoals: z.string({ required_error: "Please select an investment goal" }),
  riskAppetite: z.string({ required_error: "Please select your risk appetite" }),
  timeframe: z.string({ required_error: "Please select your investment timeframe" }),
  holdings: z.array(cryptoHoldingSchema).min(1, "Please add at least one holding"),
  txHash: z.string().optional(),
});

export const insertAnalysisRequestSchema = createInsertSchema(analysisRequests).pick({
  name: true,
  email: true,
  investmentGoals: true,
  riskAppetite: true,
  timeframe: true,
  holdings: true,
  txHash: true,
  status: true,
});

export type InsertAnalysisRequest = z.infer<typeof insertAnalysisRequestSchema>;
export type AnalysisRequest = typeof analysisRequests.$inferSelect;
